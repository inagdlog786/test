import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StoreAddsComponent } from './store-adds.component';

describe('StoreAddsComponent', () => {
  let component: StoreAddsComponent;
  let fixture: ComponentFixture<StoreAddsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StoreAddsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StoreAddsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
