import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-store-adds',
  templateUrl: './store-adds.component.html',
  styleUrls: ['./store-adds.component.css']
})
export class StoreAddsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
