import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newcollection',
  templateUrl: './newcollection.component.html',
  styleUrls: ['./newcollection.component.css']
})
export class NewcollectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
