import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RelatedprodcutsComponent } from './relatedprodcuts.component';

describe('RelatedprodcutsComponent', () => {
  let component: RelatedprodcutsComponent;
  let fixture: ComponentFixture<RelatedprodcutsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RelatedprodcutsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RelatedprodcutsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
