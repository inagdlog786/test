import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-relatedprodcuts',
  templateUrl: './relatedprodcuts.component.html',
  styleUrls: ['./relatedprodcuts.component.css']
})
export class RelatedprodcutsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
