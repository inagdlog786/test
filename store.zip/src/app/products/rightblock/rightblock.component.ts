import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rightblock',
  templateUrl: './rightblock.component.html',
  styleUrls: ['./rightblock.component.css']
})
export class RightblockComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
