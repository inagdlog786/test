import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LeftblockComponent } from './leftblock.component';

describe('LeftblockComponent', () => {
  let component: LeftblockComponent;
  let fixture: ComponentFixture<LeftblockComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LeftblockComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LeftblockComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
