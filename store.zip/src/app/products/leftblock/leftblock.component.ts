import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leftblock',
  templateUrl: './leftblock.component.html',
  styleUrls: ['./leftblock.component.css']
})
export class LeftblockComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
