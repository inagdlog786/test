import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PdleftComponent } from './pdleft.component';

describe('PdleftComponent', () => {
  let component: PdleftComponent;
  let fixture: ComponentFixture<PdleftComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PdleftComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PdleftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
