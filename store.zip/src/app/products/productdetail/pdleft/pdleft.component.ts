import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pdleft',
  templateUrl: './pdleft.component.html',
  styleUrls: ['./pdleft.component.css']
})
export class PdleftComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
