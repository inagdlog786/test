import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PdrightComponent } from './pdright.component';

describe('PdrightComponent', () => {
  let component: PdrightComponent;
  let fixture: ComponentFixture<PdrightComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PdrightComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PdrightComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
