import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pdright',
  templateUrl: './pdright.component.html',
  styleUrls: ['./pdright.component.css']
})
export class PdrightComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
