import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { MenuComponent } from './header/menu/menu.component';
import { SliderComponent } from './header/slider/slider.component';
import { StoreAddsComponent } from './home/store-adds/store-adds.component';
import { HomeComponent } from './home/home.component';
import { NewcollectionComponent } from './home/newcollection/newcollection.component';
import { SpecialofferComponent } from './home/specialoffer/specialoffer.component';
import { NewsletterComponent } from './home/newsletter/newsletter.component';
import { FooterComponent } from './footer/footer.component';
import { MyaccountComponent } from './myaccount/myaccount.component';
import { LoginComponent } from './myaccount/login/login.component';
import { RegisterComponent } from './myaccount/register/register.component';
import { BreadcrumbsComponent } from './breadcrumbs/breadcrumbs.component';
import { ProductsComponent } from './products/products.component';
import { LeftblockComponent } from './products/leftblock/leftblock.component';
import { RightblockComponent } from './products/rightblock/rightblock.component';
import { ProductdetailComponent } from './products/productdetail/productdetail.component';
import { RelatedprodcutsComponent } from './products/relatedprodcuts/relatedprodcuts.component';
import { PdleftComponent } from './products/productdetail/pdleft/pdleft.component';
import { PdrightComponent } from './products/productdetail/pdright/pdright.component';
import { CheckoutComponent } from './products/checkout/checkout.component';
import { ContactusComponent } from './contactus/contactus.component';


const appRoutes: Routes = [
  { path: '', component: HomeComponent},
  { path: 'login', component: LoginComponent},
  { path: 'register', component: RegisterComponent},
  { path: 'products', component: ProductsComponent},
  { path: 'contactus', component: ContactusComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    MenuComponent,
    SliderComponent,
    StoreAddsComponent,
    HomeComponent,
    NewcollectionComponent,
    SpecialofferComponent,
    NewsletterComponent,
    FooterComponent,
    MyaccountComponent,
    LoginComponent,
    RegisterComponent,
    BreadcrumbsComponent,
    ProductsComponent,
    LeftblockComponent,
    RightblockComponent,
    ProductdetailComponent,
    RelatedprodcutsComponent,
    PdleftComponent,
    PdrightComponent,
    CheckoutComponent,
    ContactusComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
