export declare function resolveProjectModule(root: string, moduleName: string): any;
export declare function requireProjectModule(root: string, moduleName: string): any;
