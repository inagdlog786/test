export declare class A11yModule {
}
