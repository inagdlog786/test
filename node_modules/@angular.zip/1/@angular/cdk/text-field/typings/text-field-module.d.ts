export declare class TextFieldModule {
}
