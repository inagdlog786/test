/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';
export { DIR_DOCUMENT_FACTORY as ɵa } from './dir-document-token';
