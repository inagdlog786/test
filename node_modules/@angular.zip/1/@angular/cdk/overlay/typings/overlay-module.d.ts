import { Provider } from '@angular/core';
export declare class OverlayModule {
}
/**
 * @deprecated Use `OverlayModule` instead.
 * @deletion-target 7.0.0
 */
export declare const OVERLAY_PROVIDERS: Provider[];
