export declare class CdkTreeModule {
}
