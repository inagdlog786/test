export const rxSubscriber = (typeof Symbol === 'function' && typeof Symbol.for === 'function')
    ? Symbol.for('rxSubscriber')
    : '@@rxSubscriber';
export const $$rxSubscriber = rxSubscriber;
//# sourceMappingURL=rxSubscriber.js.map