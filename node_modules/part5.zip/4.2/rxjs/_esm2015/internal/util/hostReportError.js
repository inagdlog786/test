export function hostReportError(err) {
    setTimeout(() => { throw err; });
}
//# sourceMappingURL=hostReportError.js.map