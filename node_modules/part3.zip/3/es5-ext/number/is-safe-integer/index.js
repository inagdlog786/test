"use strict";

module.exports = require("./is-implemented")()
	? Number.isSafeInteger
	: require("./shim");
