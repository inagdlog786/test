import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { Routes, RouterModule } from '@angular/router';
import { ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpModule, Http , Response, Headers } from '@angular/http';
import { HttpResponse, HttpHeaders, HttpClient, HttpClientModule } from '@angular/common/http';
import { MaterialModule } from './material/material.module';

import { AppComponent } from './app.component';
import { CocoComponent } from './coco/coco.component';
import { VendorComponent } from './coco/vendor/vendor.component';
import { ResignationComponent } from './coco/resignation/resignation.component';
import { AreamanagerComponent } from './coco/areamanager/areamanager.component';
import { StateheadComponent } from './coco/statehead/statehead.component';

import { MasterTemplateComponent } from './master-template/master-template.component';
import { SearchrequestPipe } from './master-template/searchrequest.pipe';
import { SaveSuccessComponent } from './coco/messages/save-success/save-success.component';
import { AmapprovedComponent } from './coco/messages/amapproved/amapproved.component';
import { AmrejectComponent } from './coco/messages/amreject/amreject.component';
import { ShrejectComponent } from './coco/messages/shreject/shreject.component';
import { ShapprovedComponent } from './coco/messages/shapproved/shapproved.component';
import { ResignComponent } from './test/resign/resign.component';

const appRoutes: Routes = [
  { path: '', component: VendorComponent},
  { path: 'resignation', component: ResignationComponent},
  { path: 'areamanager', component: AreamanagerComponent},
  { path: 'statehead', component: StateheadComponent},
  { path: 'demo', component: MasterTemplateComponent},
  { path: 'demo1', component: ResignComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    CocoComponent,
    VendorComponent,
    ResignationComponent,
    AreamanagerComponent,
    StateheadComponent,
    MasterTemplateComponent,
    SearchrequestPipe,
    SaveSuccessComponent,
    AmapprovedComponent,
    AmrejectComponent,
    ShrejectComponent,
    ShapprovedComponent,
    ResignComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoutes),
    HttpModule,
    HttpClientModule,
    MaterialModule
  ],
  providers: [],
  entryComponents: [SaveSuccessComponent, AmapprovedComponent, AmrejectComponent,
    ShrejectComponent,
    ShapprovedComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
