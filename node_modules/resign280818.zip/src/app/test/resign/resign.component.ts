import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators  } from '@angular/forms';

import {MatSnackBar} from '@angular/material';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';

import {MAT_MOMENT_DATE_FORMATS, MomentDateAdapter} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';

import * as _moment from 'moment';
import {default as _rollupMoment} from 'moment';
import { ResignationService } from '../../services/resignation.service';
import { SaveSuccessComponent } from '../../coco/messages/save-success/save-success.component';

const moment = _rollupMoment || _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'l',
  },
  display: {
    dateInput: 'l',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'l',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
moment.updateLocale('en', {
    longDateFormat : {
        LT: 'h:mm A',
        LTS: 'h:mm:ss A',
        L: 'MM/DD/YYYY',
        l: 'D/M/YYYY',
        LL: 'MMMM Do YYYY',
        ll: 'MMM D YYYY',
        LLL: 'MMMM Do YYYY LT',
        lll: 'MMM D YYYY LT',
        LLLL: 'dddd, MMMM Do YYYY LT',
        llll: 'ddd, MMM D YYYY LT'
    }
});

export interface Rol {
  value: string;
  viewValue: string;
}
export interface Reason {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-resign',
  templateUrl: './resign.component.html',
  styleUrls: ['./resign.component.css']
})
export class ResignComponent implements OnInit {

  SaveSuccess: MatDialogRef<SaveSuccessComponent, any>;

  rols: Rol[] = [
    {value: 'rjf023-0', viewValue: 'RJF023'},
  ];
  reasons: Reason[] = [
    {value: 'Reason-0', viewValue: 'Financial problems'}
  ];

  minDate = new Date();
  resd = new FormControl(new Date());
  reld = new FormControl(moment().add(1, 'months'));
  hotod = new FormControl(moment().add(1, 'months'));

  profileForm = this.fb.group({
    rolcode: ['', Validators.required],
    Engagementnumber: ['', Validators.required]
  });

  constructor(
    public dialog: MatDialog,
    public snackBar: MatSnackBar,
    private fb: FormBuilder,
    private _resignation: ResignationService
  ){this.getRoCode();}


  roCodeData: any;
  headerData: {};
  finalDate: any;
  Engagementnumber: any;
  Operatorcode: any;
  VendorName: any;
  oReasonData: any;

  resignDate: any;
  relievdt: any;
  hotodt: any;
  roSelection: any;
  reasonSelection: any;
  resigndt: any;

  getRoCode() {
    let roCode = 'ROCODE';
    let input = 'OPERATORCODE';
    this._resignation.getOperatorROCode(roCode, input).subscribe(rolCode => {
      debugger;
      this.roCodeData = rolCode['d'].results;
      this.getHeaderSet('');
    });
  }
  getHeaderSet(roValue) {
    let vendor = '100592';
    let rocode = roValue;
    this._resignation.getOperatorHeaderSet(vendor, rocode).subscribe(headerSet => {
      this.headerData = headerSet['d'].results[0];
      this.Engagementnumber = headerSet['d'].results[0].Engagementnumber;
      this.Operatorcode = headerSet['d'].results[0].Operatorcode;
      this.VendorName = headerSet['d'].results[0].VendorName;

      if(headerSet['d'].results[0].Engagementdate){
        let value = headerSet['d'].results[0].Engagementdate.substring(6, (headerSet['d'].results[0].Engagementdate.length - 8));
        let valuez = new Date(parseInt(value));
        let mon = '' + valuez.getMonth() + 1;
        let day = '' + valuez.getDate();
        let yr = valuez.getFullYear();

        if (mon.length < 2) { mon = '0' + mon;  }
        if (day.length < 2) { day = '0' + day;  }
        this.finalDate = day + '/' + mon + '/' + yr;
        }
    });
  }
  onROChange(evt){
    let selectedRo = evt.value;
    this.getHeaderSet(selectedRo);
  }

  getOReason() {
    let oReason = 'REASON';
    let input = 'OPERATORCODE';
    this._resignation.getOperatorROCode(oReason, input).subscribe(OpReason => {
      this.oReasonData = OpReason['d'].results;
    });
  }

  resignationSaveSet() {
    let b = engageno.value;
    let resignDate = moment(resigndt.value, 'D/M/YYYY', true).format('YYYY-MM-DDTHH:mm:ss');
    let RelvDate = moment(relievdt.value, 'D/M/YYYY', true).format('YYYY-MM-DDTHH:mm:ss');
    let HotoDate = moment(hotodt.value, 'D/M/YYYY', true).format('YYYY-MM-DDTHH:mm:ss');
    let saveset = {
      Rocode: this.roSelection,
      Trackingnumber: this.headerData['Engagementnumber'],
      Operatorcode: this.headerData['Operatorcode'],
      ResgDt: resignDate,
      RelvDt: RelvDate,
      HotoDt: HotoDate,
      Reason: this.reasonSelection,
      Newoperator: '0000100593',
      // Newoperator: '',
      Flag: 'C'
    };

    let saveset1 = {
      Rocode: '70001',
      Trackingnumber: '000000080',
      Operatorcode: '0000100592',
      ResgDt: '2018-08-22T00:00:00',
      RelvDt: '2018-08-22T00:00:00',
      HotoDt: '2018-08-22T00:00:00',
      Reason: '01',
      Newoperator: '0000100593',
      Flag: 'C'
    };

    this._resignation.dummyDataCall().then((data) => {
      let t = JSON.parse(JSON.stringify(data.headers));
      let token = t['x-csrf-token'][0];

    this._resignation.operatorResignationSaveSet(saveset, token).subscribe(data => {
      debugger;
      let msg= data['d'].Message;
      let resgNo= data['d'].EvResgNo;
      var saveMsg= msg+ " " +resgNo;
      this.openSaveSuccess(saveMsg);
    },
    error => {
      let msg= "not Saved SUccessfully";
      this.openSaveSuccess('Error');
    });
  });

  }
  public openSaveSuccess(msg) {
    this.SaveSuccess = this.dialog.open(SaveSuccessComponent, {
      // hasBackdrop: false
      data: msg
    });
  }


  ngOnInit() {
  }
  hotoDateChange(evt){
    this.hotodt = moment(evt.value._d,'ddd MMMM DD YYYY HH:mm:ss',true).format('l');
  }
  relvDateChange(evt){
    this.relievdt = moment(evt.value._d,'ddd MMMM DD YYYY HH:mm:ss',true).format('l');
  }

  // resignDetail(evt) {
  //   this.checkActiveTabIndex = evt.index;
  // }

  onSubmit() {
    if (this.profileForm.valid) {
      console.warn(this.profileForm.value);
    } else{
      console.warn('Fileds are required');
    }
  }

}
