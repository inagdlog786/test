import { TestBed, inject } from '@angular/core/testing';

import { ResignationService } from './resignation.service';

describe('ResignationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ResignationService]
    });
  });

  it('should be created', inject([ResignationService], (service: ResignationService) => {
    expect(service).toBeTruthy();
  }));
});
