import { Injectable } from '@angular/core';
// import { Http, HttpModule, Response, Headers } from '@angular/http';
// import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
// import { HttpResponse, HttpHeaders, HttpClient } from '@angular/common/http';

import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class ResignationService {

  constructor(private _resignationOperator: Http, private http: HttpClient) { }

  getOperatorROCode(value1, value2) {
    // const url = 'http://fioridev.ril.com/sap/opu/odata/sap/Z_resignation_SRV/Resign_f4Set?$filter=Indicator eq \'ROCODE\'';
    const url =
    // tslint:disable-next-line:max-line-length
    'http://fioridev.ril.com/sap/opu/odata/sap/Z_resignation_SRV/Resign_f4Set?$filter=Indicator eq \'' + value1 + '\' and input1 eq \'' + value2 + '\'';
    return this._resignationOperator.get(url).pipe(map((response: Response) => <any[]>response.json()));
  }

  getOperatorHeaderSet(value1, value2) {
    // tslint:disable-next-line:max-line-length
    const url = 'http://fioridev.ril.com/sap/opu/odata/sap/Z_resignation_SRV/ResignHeaderSet?$filter=Vendor eq \'' + value1 + '\' and Rocode eq \'' + value2 + '\'';
    return this._resignationOperator.get(url).pipe(map((response: Response) => <any[]>response.json()));
  }

  getOperatorReason(reason) {
    // tslint:disable-next-line:max-line-length
    const url = 'http://fioridev.ril.com/sap/opu/odata/sap/Z_resignation_SRV/Resign_f4Set?$filter=Indicator eq \'' + reason + '\'';
    return this._resignationOperator.get(url).pipe(map((response: Response) => <any[]>response.json()));
  }

// Resignation Save
  dummyDataCall() {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    headers.append('x-csrf-token', 'fetch');
    let options = new RequestOptions({
      headers: headers,
      method: 'GET'
    });
    return this._resignationOperator.get('http://fioridev.ril.com/sap/opu/odata/sap/Z_RESIGNATION_SRV', options)
    .toPromise()
    .then((response) => {
      return response;
    });
    }

    operatorResignationSaveSet(payload, token): Observable<any> {
      let httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'x-csrf-token': token
        })
      };
      let options = {
        headers: httpOptions,
        method: 'POST',
        body: (payload)
      };
      const url = 'http://fioridev.ril.com/sap/opu/odata/sap/Z_RESIGNATION_SRV/ResignSaveSet';
      return this.http.post(url, options.body, httpOptions).pipe(map((res: Response) =>
        <any>res));
    }
// Resignation Save Close

}
