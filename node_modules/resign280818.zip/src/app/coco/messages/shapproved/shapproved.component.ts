import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shapproved',
  templateUrl: './shapproved.component.html',
  styleUrls: ['./shapproved.component.css']
})
export class ShapprovedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
