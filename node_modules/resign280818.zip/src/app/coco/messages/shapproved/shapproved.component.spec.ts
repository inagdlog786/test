import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShapprovedComponent } from './shapproved.component';

describe('ShapprovedComponent', () => {
  let component: ShapprovedComponent;
  let fixture: ComponentFixture<ShapprovedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShapprovedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShapprovedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
