import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AmrejectComponent } from './amreject.component';

describe('AmrejectComponent', () => {
  let component: AmrejectComponent;
  let fixture: ComponentFixture<AmrejectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AmrejectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AmrejectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
