import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-amreject',
  templateUrl: './amreject.component.html',
  styleUrls: ['./amreject.component.css']
})
export class AmrejectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
