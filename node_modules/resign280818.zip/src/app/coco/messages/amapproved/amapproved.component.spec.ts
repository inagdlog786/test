import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AmapprovedComponent } from './amapproved.component';

describe('AmapprovedComponent', () => {
  let component: AmapprovedComponent;
  let fixture: ComponentFixture<AmapprovedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AmapprovedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AmapprovedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
