import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-amapproved',
  templateUrl: './amapproved.component.html',
  styleUrls: ['./amapproved.component.css']
})
export class AmapprovedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
