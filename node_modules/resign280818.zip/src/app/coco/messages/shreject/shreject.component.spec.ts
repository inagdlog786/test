import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShrejectComponent } from './shreject.component';

describe('ShrejectComponent', () => {
  let component: ShrejectComponent;
  let fixture: ComponentFixture<ShrejectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShrejectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShrejectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
