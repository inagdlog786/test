import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shreject',
  templateUrl: './shreject.component.html',
  styleUrls: ['./shreject.component.css']
})
export class ShrejectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
