import { Component, OnInit } from '@angular/core';
import {FormControl} from '@angular/forms';
import {MatTableDataSource} from '@angular/material';
import {MatSnackBar} from '@angular/material';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { SaveSuccessComponent } from '../messages/save-success/save-success.component';

import {MAT_MOMENT_DATE_FORMATS, MomentDateAdapter} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';

import * as _moment from 'moment';
import {default as _rollupMoment} from 'moment';
import { AmapprovedComponent } from '../messages/amapproved/amapproved.component';
import { AmrejectComponent } from '../messages/amreject/amreject.component';

const moment = _rollupMoment || _moment;

export interface Rol {
  value: string;
  viewValue: string;
}
export interface Attachment {
  value: string;
  viewValue: string;
}
export interface Reason {
  value: string;
  viewValue: string;
}

export interface RequestNo {
  requestno: string;
  rocode: string;
  operator: string;
  areamanager: string;
  statehead: string;
  date: string;
  status: string;
}

export const MY_FORMATS = {
  parse: {
    dateInput: 'l',
  },
  display: {
    dateInput: 'l',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'l',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
moment.updateLocale('en', {
    longDateFormat : {
        LT: 'h:mm A',
        LTS: 'h:mm:ss A',
        L: 'MM/DD/YYYY',
        l: 'D/M/YYYY',
        LL: 'MMMM Do YYYY',
        ll: 'MMM D YYYY',
        LLL: 'MMMM Do YYYY LT',
        lll: 'MMM D YYYY LT',
        LLLL: 'dddd, MMMM Do YYYY LT',
        llll: 'ddd, MMM D YYYY LT'
    }
});
const ELEMENT_DATA: RequestNo[] = [
  { requestno: 'RHF0011', rocode: 'RJF023',
  operator: 'Rama',
  areamanager: 'Krishan',
  statehead: 'Govinda',
  date: '13/08/2018',
  status: 'Approved'
  },
  { requestno: 'RHF0012', rocode: 'RJF024',
  operator: 'James',
  areamanager: 'Hawkins',
  statehead: 'David',
  date: '06/08/2018',
  status: 'Rejected'
  }
];

@Component({
  selector: 'app-areamanager',
  templateUrl: './areamanager.component.html',
  styleUrls: ['./areamanager.component.css'],
  providers: [
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
    {provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS},
  ],
})
export class AreamanagerComponent implements OnInit {
  SaveSuccess: any;
  rols: Rol[] = [
    {value: 'rjf023-0', viewValue: 'RJF023'},
    {value: 'rjf024-1', viewValue: 'RJF024'},
    {value: 'rjf025-2', viewValue: 'RJF025'},
    {value: 'rjf026-3', viewValue: 'RJF026'}
  ];
  attachments: Attachment[] = [
    {value: 'XLS-0', viewValue: 'XLS'},
    {value: 'PDF-1', viewValue: 'PDF'},
    {value: 'JPG-2', viewValue: 'JPG'}
  ];
  reasons: Reason[] = [
    {value: 'Reason-0', viewValue: 'Reason 01'},
    {value: 'Reason-1', viewValue: 'Reason 02'},
    {value: 'Other-2', viewValue: 'Others'}
  ];


  resd = new FormControl(new Date());
  reld = new FormControl(moment().add(1, 'months'));
  hotod = new FormControl(moment().add(1, 'months'));
  selected = 'rjf023-0';

  displayedColumns: string[] = ['requestno'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  constructor(
    public dialog: MatDialog,
    public snackBar: MatSnackBar
  ) {}

  public openSaveSuccess() {
    this.SaveSuccess = this.dialog.open(SaveSuccessComponent, {
      // hasBackdrop: false
    });
  }

  public openApproved() {
    this.SaveSuccess = this.dialog.open(AmapprovedComponent, {
      // hasBackdrop: false
    });
  }

  public openReject() {
    this.SaveSuccess = this.dialog.open(AmrejectComponent, {
      // hasBackdrop: false
    });
  }

  ngOnInit() {

  }

}
