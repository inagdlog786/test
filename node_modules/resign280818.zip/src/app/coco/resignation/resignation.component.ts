import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, AbstractControl, FormBuilder, Validators } from '@angular/forms';

import { MatSnackBar } from '@angular/material';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SaveSuccessComponent } from '../messages/save-success/save-success.component';

import { MAT_MOMENT_DATE_FORMATS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';


import * as _moment from 'moment';
import { default as _rollupMoment } from 'moment';
import { ResignationService } from '../../services/resignation.service';

const moment = _rollupMoment || _moment;
export interface OSaveSet {
  rolcode: string;
  engageno: number;
  engagedt: string;
  operatorcode: string;
  resigndt: string;
  relievdt: string;
  hotodt: string;
  reason: string;
}
export interface Rol {
  value: string;
  viewValue: string;
}
export interface Attachment {
  value: string;
  viewValue: string;
}
export interface Reason {
  value: string;
  viewValue: string;
}
export const MY_FORMATS = {
  parse: {
    dateInput: 'l',
  },
  display: {
    dateInput: 'l',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'l',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
moment.updateLocale('en', {
  longDateFormat: {
    LT: 'h:mm A',
    LTS: 'h:mm:ss A',
    L: 'MM/DD/YYYY',
    l: 'D/M/YYYY',
    LL: 'MMMM Do YYYY',
    ll: 'MMM D YYYY',
    LLL: 'MMMM Do YYYY LT',
    lll: 'MMM D YYYY LT',
    LLLL: 'dddd, MMMM Do YYYY LT',
    llll: 'ddd, MMM D YYYY LT',

  }
});


@Component({
  selector: 'app-resignation',
  templateUrl: './resignation.component.html',
  styleUrls: ['./resignation.component.css'],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
})
export class ResignationComponent implements OnInit {
  // reasonSelection:string;
  // roSelection: string;
  // engageno: number;
  // resigndt: string;
  // relievdt: string;
  // hotodt: string;

  checkActiveTabIndex = 0;

  SaveSuccess: MatDialogRef<SaveSuccessComponent, any>;
  rols: Rol[] = [
    { value: 'rjf023-0', viewValue: 'RJF023' },
  ];
  attachments: Attachment[] = [
    { value: 'file-0', viewValue: 'File type 01' },
    { value: 'file-1', viewValue: 'File type 02' },
    { value: 'file-2', viewValue: 'File type 03' }
  ];
  reasons: Reason[] = [
    { value: 'Reason-0', viewValue: 'Financial problems' },
    { value: 'Reason-1', viewValue: 'Reason 02' },
    { value: 'Other-2', viewValue: 'Others' }
  ];
  reason = 'Financial problems';
  // date = new FormControl(new Date());
  // date1 = new FormControl(moment().add(1, 'months'));
  // date2 = new FormControl(moment().add(25, 'days'));

  minDate = new Date();
  resd = new FormControl(new Date());
  reld = new FormControl(moment().add(1, 'months'));
  hotod = new FormControl(moment().add(1, 'months'));

  selected = 'rjf023-0';

  resignOperatorForm = this.fb.group({
    rolCodeR: ['', Validators.required],
    opeartorReasonR: ['', Validators.required],
    // relDateR: ['', Validators.required],
    // hotoDateR: ['', Validators.required]
  });

  Engagementnumber: any;
  Operatorcode: any;
  VendorName: any;
  oReasonData: any;
  buttonDisabled: any;

  roCodeData: any;
  headerData = {};
  finalDate: any;
  // d: any[];
  engageno = {};
  resignDate: any;
  relievdt: any;
  hotodt: any;
  roSelection: any;
  reasonSelection: any;
  resigndt: any;

  constructor(public dialog: MatDialog, private _resignation: ResignationService,
    private fb: FormBuilder, ) {
    this.getRoCode();
    this.getOReason();
    this.buttonDisabled = true;
  }

  getRoCode() {
    let roCode = 'ROCODE';
    let input = 'OPERATORCODE';
    this._resignation.getOperatorROCode(roCode, input).subscribe(rolCode => {
      this.roCodeData = rolCode['d'].results;
      // console.log(this.roCodeData);
      // this.getHeaderSet(this.roCodeData[0].Field1);
      this.getHeaderSet('');
    });
  }
  getHeaderSet(roValue) {
    let vendor = '100592';
    // let vendor = 'OPERATORCODE';


    let rocode = roValue;
    this._resignation.getOperatorHeaderSet(vendor, rocode).subscribe(headerSet => {
      this.headerData = headerSet['d'].results[0];
      this.Engagementnumber = headerSet['d'].results[0].Engagementnumber;
      this.Operatorcode = headerSet['d'].results[0].Operatorcode;
      this.VendorName = headerSet['d'].results[0].VendorName;

      if (headerSet['d'].results[0].Engagementdate) {
        let value = headerSet['d'].results[0].Engagementdate.substring(6, (headerSet['d'].results[0].Engagementdate.length - 8));
        let valuez = new Date(parseInt(value));
        let mon = '' + valuez.getMonth() + 1;
        let day = '' + valuez.getDate();
        let yr = valuez.getFullYear();

        if (mon.length < 2) {
          mon = '0' + mon;
        }
        if (day.length < 2) {
          day = '0' + day;
        }
        this.finalDate = day + '/' + mon + '/' + yr;
      }

      // console.log(this.finalDate);
      // console.log(this.headerData);
    });
  }
  onROChange(evt) {
    let selectedRo = evt.value;
    // debugger;
    this.getHeaderSet(selectedRo);
  }

  getOReason() {
    let oReason = 'REASON';
    let input = 'OPERATORCODE';
    this._resignation.getOperatorROCode(oReason, input).subscribe(OpReason => {
      this.oReasonData = OpReason['d'].results;
      console.log(this.oReasonData);
    });
  }

// Save and Submit
  createPayload(type){
    let b = engageno.value;
    let resignDate = moment(resigndt.value, 'D/M/YYYY', true).format('YYYY-MM-DDTHH:mm:ss');
    let RelvDate = moment(relievdt.value, 'D/M/YYYY', true).format('YYYY-MM-DDTHH:mm:ss');
    let HotoDate = moment(hotodt.value, 'D/M/YYYY', true).format('YYYY-MM-DDTHH:mm:ss');
    let saveset = {
      Rocode: this.roSelection,
      Trackingnumber: this.headerData['Engagementnumber'],
      Operatorcode: this.headerData['Operatorcode'],
      ResgDt: resignDate,
      RelvDt: RelvDate,
      HotoDt: HotoDate,
      Reason: this.reasonSelection,
      Newoperator: '0000100593',
      // Newoperator: '',
      Flag: type
    };
    return saveset;
  }

  resignationSaveSet() {

    // if(this.checkActiveTabIndex){
    //   alert("Attachment Tab");
    // }else{
    //   alert("Resignation Tab");

    // }
    // return false;

    // let b = engageno.value;
    // let resignDate = moment(resigndt.value, 'D/M/YYYY', true).format('YYYY-MM-DDTHH:mm:ss');
    // let RelvDate = moment(relievdt.value, 'D/M/YYYY', true).format('YYYY-MM-DDTHH:mm:ss');
    // let HotoDate = moment(hotodt.value, 'D/M/YYYY', true).format('YYYY-MM-DDTHH:mm:ss');
    // let saveset = {
    //   Rocode: this.roSelection,
    //   Trackingnumber: this.headerData['Engagementnumber'],
    //   Operatorcode: this.headerData['Operatorcode'],
    //   ResgDt: resignDate,
    //   RelvDt: RelvDate,
    //   HotoDt: HotoDate,
    //   Reason: this.reasonSelection,
    //   Newoperator: '0000100593',
    //   // Newoperator: '',
    //   Flag: 'C'
    // };

    // let saveset1 = {
    //   Rocode: '70001',
    //   Trackingnumber: '000000080',
    //   Operatorcode: '0000100592',
    //   ResgDt: '2018-08-22T00:00:00',
    //   RelvDt: '2018-08-22T00:00:00',
    //   HotoDt: '2018-08-22T00:00:00',
    //   Reason: '01',
    //   Newoperator: '0000100593',
    //   Flag: 'C'
    // };



    let type = 'C';
    let saveset =this.createPayload(type);

    this._resignation.dummyDataCall().then((data) => {
      let t = JSON.parse(JSON.stringify(data.headers));
      let token = t['x-csrf-token'][0];

      this._resignation.operatorResignationSaveSet(saveset, token).subscribe(data => {
        debugger;
        let msg = data['d'].Message;
        let resgNo = data['d'].EvResgNo;
        var saveMsg = msg + " " + resgNo;

        if (this.resignOperatorForm.valid) {
          this.openSaveSuccess(saveMsg);
          this.buttonDisabled = false;
        } else {
          this.openSaveSuccess('Fileds are required');
          this.buttonDisabled = true;
        }
      },
        error => {
          let msg = "not Saved SUccessfully";
          this.openSaveSuccess('Error jjj');
          alert('R');
          this.buttonDisabled = true;
        });
    });

  }
  // Submit
  resignationSubmitSet() {
    let type = 'S';
    let saveset = this.createPayload(type);
    this._resignation.dummyDataCall().then((data) => {
      let t = JSON.parse(JSON.stringify(data.headers));
      let token = t['x-csrf-token'][0];

      this._resignation.operatorResignationSaveSet(saveset, token).subscribe(data => {
        debugger;
        let msg = data['d'].Message;
        let resgNo = data['d'].EvResgNo;
        var saveMsg = msg;

        if (this.resignOperatorForm.valid) {
          this.openSaveSuccess(saveMsg);
        } else {
          // this.openSaveSuccess('Fileds are required');
          alert(666);
        }
      },
        error => {
          let msg = "not Saved SUccessfully";
          // this.openSaveSuccess('Error jjj');
          alert('R');
        });
    });

  }
  // Save and Submit close

  public openSaveSuccess(msg) {
    this.SaveSuccess = this.dialog.open(SaveSuccessComponent, {
      // hasBackdrop: false
      data: msg
    });
  }
  ngOnInit() {
  }
  hotoDateChange(evt) {
    // debugger;
    this.hotodt = moment(evt.value._d, 'ddd MMMM DD YYYY HH:mm:ss', true).format('l');

  }
  relvDateChange(evt) {
    // debugger;
    this.relievdt = moment(evt.value._d, 'ddd MMMM DD YYYY HH:mm:ss', true).format('l');

  }

  resignDetail(evt) {
    debugger;
    this.checkActiveTabIndex = evt.index;
  }

}
