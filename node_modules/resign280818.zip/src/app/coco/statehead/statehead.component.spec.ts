import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StateheadComponent } from './statehead.component';

describe('StateheadComponent', () => {
  let component: StateheadComponent;
  let fixture: ComponentFixture<StateheadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StateheadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StateheadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
