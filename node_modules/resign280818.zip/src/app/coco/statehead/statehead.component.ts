import { Component, OnInit, Input } from '@angular/core';
import {FormControl} from '@angular/forms';

import {MatTableDataSource} from '@angular/material';
import {MatSnackBar} from '@angular/material';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { SaveSuccessComponent } from '../messages/save-success/save-success.component';

import {MAT_MOMENT_DATE_FORMATS, MomentDateAdapter} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';

import * as _moment from 'moment';
import {default as _rollupMoment} from 'moment';
import { ShapprovedComponent } from '../messages/shapproved/shapproved.component';
import { ShrejectComponent } from '../messages/shreject/shreject.component';

const moment = _rollupMoment || _moment;

export interface Rol {
  value: string;
  viewValue: string;
}
export interface Attachment {
  value: string;
  viewValue: string;
}
export interface Reason {
  value: string;
  viewValue: string;
}

export interface RequestNo {
  requestno: string;
  rocode: string;
  operator: string;
  areamanager: string;
  statehead: string;
  date: string;
  status: string;
}
export interface Vncode {
  vcode: number;
  vname: string;
}
export const VNCODES: Vncode[] = [
  { vcode: 11, vname: 'Balaji Enterprises' },
  { vcode: 12, vname: 'Narco' },
  { vcode: 13, vname: 'Bombasto' },
  { vcode: 14, vname: 'Celeritas' },
  { vcode: 15, vname: 'Magneta' },
  { vcode: 16, vname: 'RubberMan' },
  { vcode: 17, vname: 'Dynama' },
  { vcode: 18, vname: 'Dr IQ' },
  { vcode: 19, vname: 'Magma' },
  { vcode: 20, vname: 'Tornado' }
];

export const MY_FORMATS = {
  parse: {
    dateInput: 'l',
  },
  display: {
    dateInput: 'l',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'l',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
moment.updateLocale('en', {
    longDateFormat : {
        LT: 'h:mm A',
        LTS: 'h:mm:ss A',
        L: 'MM/DD/YYYY',
        l: 'D/M/YYYY',
        LL: 'MMMM Do YYYY',
        ll: 'MMM D YYYY',
        LLL: 'MMMM Do YYYY LT',
        lll: 'MMM D YYYY LT',
        LLLL: 'dddd, MMMM Do YYYY LT',
        llll: 'ddd, MMM D YYYY LT'
    }
});
const ELEMENT_DATA: RequestNo[] = [
  { requestno: 'RHF0011', rocode: 'RJF023',
  operator: 'Rama',
  areamanager: 'Krishan',
  statehead: 'Govinda',
  date: '13/08/2018',
  status: 'Approved'
  },
  { requestno: 'RHF0012', rocode: 'RJF024',
  operator: 'James',
  areamanager: 'Hawkins',
  statehead: 'David',
  date: '06/08/2018',
  status: 'Rejected'
  }
];

@Component({
  selector: 'app-statehead',
  templateUrl: './statehead.component.html',
  styleUrls: ['./statehead.component.css'],
  providers: [
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ],
})
export class StateheadComponent implements OnInit {
  SaveSuccess: any;
rols: Rol[] = [
  {value: 'rjf023-0', viewValue: 'RJF023'},
  {value: 'rjf024-1', viewValue: 'RJF024'},
  {value: 'rjf025-2', viewValue: 'RJF025'},
  {value: 'rjf026-3', viewValue: 'RJF026'}
];
attachments: Attachment[] = [
  {value: 'XLS-0', viewValue: 'XLS'},
  {value: 'PDF-1', viewValue: 'PDF'},
  {value: 'JPG-2', viewValue: 'JPG'}
];
reasons: Reason[] = [
  {value: 'Reason-0', viewValue: 'Reason 01'},
  {value: 'Reason-1', viewValue: 'Reason 02'},
  {value: 'Other-2', viewValue: 'Others'}
];

  @Input() VNCODE: Vncode;
  vncodes = VNCODES;
  selectedVncode: Vncode =  {
    vcode:  12345,
    vname:  'Balaji Enterprizes'
    };

resd = new FormControl(new Date());
reld = new FormControl(moment().add(1, 'months'));
hotod = new FormControl(moment().add(1, 'months'));
selected = 'rjf023-0';

displayedColumns: string[] = ['requestno'];
dataSource = new MatTableDataSource(ELEMENT_DATA);

applyFilter(filterValue: string) {
  this.dataSource.filter = filterValue.trim().toLowerCase();
}

constructor(
  public dialog: MatDialog,
  public snackBar: MatSnackBar
) {}
// openSaveSuccess() {
//   this.snackBar.openFromComponent(SaveSuccessComponent, {
//     duration: 500,
//   });
// }

public openSaveSuccess() {
  this.SaveSuccess = this.dialog.open(SaveSuccessComponent, {
    // hasBackdrop: false
  });
}

public openApproved() {
  this.SaveSuccess = this.dialog.open(ShapprovedComponent, {
    // hasBackdrop: false
  });
}

public openReject() {
  this.SaveSuccess = this.dialog.open(ShrejectComponent, {
    // hasBackdrop: false
  });
}

  ngOnInit() {
  }

  onSelect(vncode: Vncode): void {
    this.selectedVncode = vncode;
  }

}
