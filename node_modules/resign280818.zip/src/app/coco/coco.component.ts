import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coco',
  templateUrl: './coco.component.html',
  styleUrls: ['./coco.component.css']
})
export class CocoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
