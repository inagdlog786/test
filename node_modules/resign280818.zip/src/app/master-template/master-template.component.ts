import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatTableDataSource } from '@angular/material';
import { MatSnackBar } from '@angular/material';
import { SaveSuccessComponent } from '../coco/messages/save-success/save-success.component';
import { duration } from 'moment';

import {MAT_MOMENT_DATE_FORMATS, MomentDateAdapter} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';

import * as _moment from 'moment';
import {default as _rollupMoment} from 'moment';

const moment = _rollupMoment || _moment;


export interface Rol {
  value: string;
  viewValue: string;
}
export interface Attachment {
  value: string;
  viewValue: string;
}
export interface Reason {
  value: string;
  viewValue: string;
}

export interface RequestNo {
  requestno: string;
  rocode: string;
  operator: string;
  areamanager: string;
  statehead: string;
  engageno: string;
  engagedt: string;
  vcode: string;
  vname: string;
}

export const MY_FORMATS = {
  parse: {
    dateInput: 'l',
  },
  display: {
    dateInput: 'l',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'l',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
moment.updateLocale('en', {
    longDateFormat : {
        LT: 'h:mm A',
        LTS: 'h:mm:ss A',
        L: 'MM/DD/YYYY',
        l: 'D/M/YYYY',
        LL: 'MMMM Do YYYY',
        ll: 'MMM D YYYY',
        LLL: 'MMMM Do YYYY LT',
        lll: 'MMM D YYYY LT',
        LLLL: 'dddd, MMMM Do YYYY LT',
        llll: 'ddd, MMM D YYYY LT'
    }
});

const requestNoData: RequestNo[] = [
  {
    requestno: 'RES001234',
    rocode: 'RJF023',
    operator: 'Rama',
    areamanager: 'Krishan',
    statehead: 'Govinda',
    engageno: 'R001',
    engagedt: '25 / 5 / 2018',
    vcode: 'R001',
    vname: 'Rama'
  },
  {
    requestno: 'RES001235',
    rocode: 'RJF024',
    operator: 'Rama',
    areamanager: 'Krishan',
    statehead: 'Govinda',
    engageno: 'R002',
    engagedt: '25 / 5 / 2018',
    vcode: 'R002',
    vname: 'Krishna'
  }
];

const List = [
  { SrNo: 'RJF023', AssetCode: '13/01/2018', Desc: 'Reliance Telecom', Qty: 'XYZ MANAGER', Rate: 'ABC Site Head', Value: 240 },
  { SrNo: '267467', AssetCode: '25/01/2018', Desc: 'Airtel Telecom', Qty: 'XYZ MANAGER', Rate: 'ABC Site Head', Value: 240 },
  { SrNo: '387677', AssetCode: '09/01/2018', Desc: 'Vodafone Telecom', Qty: 'XYZ MANAGER', Rate: 'ABC Site Head', Value: 240 },
  { SrNo: '564534', AssetCode: '11/01/2018', Desc: 'Reliance Telecom', Qty: 'XYZ MANAGER', Rate: 'ABC Site Head', Value: 240 },
  { SrNo: '554356', AssetCode: '29/01/2018', Desc: 'Reliance Telecom', Qty: 'XYZ MANAGER', Rate: 'ABC Site Head', Value: 240 }
];

@Component({
  selector: 'app-master-template',
  templateUrl: './master-template.component.html',
  styleUrls: ['./master-template.component.css'],
  providers: [
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ]
})
export class MasterTemplateComponent implements OnInit {

  MasterListData = Object.assign(List);
  OperatorData = Object.assign(requestNoData);

  rols: Rol[] = [
    { value: 'rjf023-0', viewValue: 'RJF023' },
    { value: 'rjf024-1', viewValue: 'RJF024' },
    { value: 'rjf025-2', viewValue: 'RJF025' },
    { value: 'rjf026-3', viewValue: 'RJF026' }
  ];
  attachments: Attachment[] = [
    { value: 'XLS-0', viewValue: 'XLS' },
    { value: 'PDF-1', viewValue: 'PDF' },
    { value: 'JPG-2', viewValue: 'JPG' }
  ];
  reasons: Reason[] = [
    { value: 'Reason-0', viewValue: 'Reason 01' },
    { value: 'Reason-1', viewValue: 'Reason 02' },
    { value: 'Other-2', viewValue: 'Others' }
  ];

  minDate = new Date();
  resd = new FormControl(new Date());
  reld = new FormControl(moment().add(1, 'months'));
  hotod = new FormControl(moment().add(1, 'months'));

  selected = 'rjf023-0';

  displayedColumns: string[] = ['requestno'];
  dataSource = new MatTableDataSource(requestNoData);


  requestFields: any;
  test: any;

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }


  constructor(public snackBar: MatSnackBar) { }

  // openSnackBar() {
  //   this.snackBar.openFromComponent(SaveSuccessComponent, {
  //     duration: 500,
  //   });
  // }

  openSnackBar() {
    this.snackBar.open('Save Succefully', 'Close', {
      duration: 5000,
    });

  }


  ngOnInit() {
    this.requestFields = this.OperatorData[0];
  }

  onListSelect(event, requestData) {
    this.requestFields = requestData;
  }

}
