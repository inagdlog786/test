import { SearchrequestPipe } from './searchrequest.pipe';

describe('SearchrequestPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchrequestPipe();
    expect(pipe).toBeTruthy();
  });
});
