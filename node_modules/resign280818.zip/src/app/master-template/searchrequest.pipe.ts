import { Injectable, Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchrequest'
})
export class SearchrequestPipe implements PipeTransform {
  _sortProperties = ['SrNo', 'AssetCode', 'Desc', 'Qty', 'Rate' ];

  transform(items: any[], value: string): any [] {
    if (!items) {
     return [];
     } else {
         if (value === '') {
             return items;
         } else {
             return items.filter((lock) => {
                 for (let i = 0; i < this._sortProperties.length; i++) {
                     // tslint:disable-next-line:prefer-const
                     let res = lock[this._sortProperties[i]].toLowerCase().match(value.toLowerCase());
                     if (res !== null) {
                         return res;
                     }
                 }
               });
         }
     }
  }

}
