import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';
import { ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpModule, Http , Response, Headers } from '@angular/http';
import { MaterialModule } from './material/material.module';

import { AppComponent } from './app.component';
import { CocoComponent } from './coco/coco.component';
import { VendorComponent } from './coco/vendor/vendor.component';
import { ResignationComponent } from './coco/resignation/resignation.component';
import { AreamanagerComponent } from './coco/areamanager/areamanager.component';
import { StateheadComponent } from './coco/statehead/statehead.component';

const appRoutes: Routes = [
  { path: '', component: VendorComponent},
  { path: 'resignation', component: ResignationComponent},
  { path: 'areamanager', component: AreamanagerComponent},
  { path: 'statehead', component: StateheadComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    CocoComponent,
    VendorComponent,
    ResignationComponent,
    AreamanagerComponent,
    StateheadComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoutes),
    HttpModule,
    MaterialModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
