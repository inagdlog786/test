import { Component, OnInit } from '@angular/core';
import {FormControl} from '@angular/forms';

export interface Rol {
  value: string;
  viewValue: string;
}
export interface Attachment {
  value: string;
  viewValue: string;
}
export interface Reason {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-resignation',
  templateUrl: './resignation.component.html',
  styleUrls: ['./resignation.component.css']
})
export class ResignationComponent implements OnInit {
  rols: Rol[] = [
    {value: 'rjf023-0', viewValue: 'RJF023'},
    {value: 'rjf024-1', viewValue: 'RJF024'},
    {value: 'rjf025-2', viewValue: 'RJF025'},
    {value: 'rjf026-3', viewValue: 'RJF026'}
  ];
  attachments: Attachment[] = [
    {value: 'XLS-0', viewValue: 'XLS'},
    {value: 'PDF-1', viewValue: 'PDF'},
    {value: 'JPG-2', viewValue: 'JPG'}
  ];
  reasons: Reason[] = [
    {value: 'Reason-0', viewValue: 'Reason 01'},
    {value: 'Reason-1', viewValue: 'Reason 02'},
    {value: 'Other-2', viewValue: 'Others'}
  ];

  date = new FormControl(new Date());
  constructor() { }

  ngOnInit() {
  }

}
