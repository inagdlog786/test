import { Component, OnInit } from '@angular/core';
import {FormControl} from '@angular/forms';
import {MatTableDataSource} from '@angular/material';

export interface Rol {
  value: string;
  viewValue: string;
}
export interface Attachment {
  value: string;
  viewValue: string;
}
export interface Reason {
  value: string;
  viewValue: string;
}

export interface RequestNo {
  requestno: string;
}

const ELEMENT_DATA: RequestNo[] = [
  { requestno: 'RH00987'}
];

@Component({
  selector: 'app-statehead',
  templateUrl: './statehead.component.html',
  styleUrls: ['./statehead.component.css']
})
export class StateheadComponent implements OnInit {rols: Rol[] = [
  {value: 'rjf023-0', viewValue: 'RJF023'},
  {value: 'rjf024-1', viewValue: 'RJF024'},
  {value: 'rjf025-2', viewValue: 'RJF025'},
  {value: 'rjf026-3', viewValue: 'RJF026'}
];
attachments: Attachment[] = [
  {value: 'XLS-0', viewValue: 'XLS'},
  {value: 'PDF-1', viewValue: 'PDF'},
  {value: 'JPG-2', viewValue: 'JPG'}
];
reasons: Reason[] = [
  {value: 'Reason-0', viewValue: 'Reason 01'},
  {value: 'Reason-1', viewValue: 'Reason 02'},
  {value: 'Other-2', viewValue: 'Others'}
];

date = new FormControl(new Date());

displayedColumns: string[] = ['requestno'];
// dataSource = new MatTableDataSource(ELEMENT_DATA);
dataSource = new MatTableDataSource(ELEMENT_DATA);

applyFilter(filterValue: string) {
  this.dataSource.filter = filterValue.trim().toLowerCase();
}

  constructor() { }

  ngOnInit() {
  }

}
