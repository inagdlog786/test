import { Observable } from 'rxjs';
import { retry } from '../../operator/retry';
Observable.prototype.retry = retry;
//# sourceMappingURL=retry.js.map