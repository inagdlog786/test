import { Observable } from 'rxjs';
import { buffer } from '../../operator/buffer';
Observable.prototype.buffer = buffer;
//# sourceMappingURL=buffer.js.map