import { Observable } from 'rxjs';
import { windowCount } from '../../operator/windowCount';
Observable.prototype.windowCount = windowCount;
//# sourceMappingURL=windowCount.js.map