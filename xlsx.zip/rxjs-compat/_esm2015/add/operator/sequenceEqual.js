import { Observable } from 'rxjs';
import { sequenceEqual } from '../../operator/sequenceEqual';
Observable.prototype.sequenceEqual = sequenceEqual;
//# sourceMappingURL=sequenceEqual.js.map