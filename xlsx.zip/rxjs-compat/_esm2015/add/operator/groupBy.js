import { Observable } from 'rxjs';
import { groupBy } from '../../operator/groupBy';
Observable.prototype.groupBy = groupBy;
//# sourceMappingURL=groupBy.js.map