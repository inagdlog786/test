import { Observable } from 'rxjs';
import { delayWhen } from '../../operator/delayWhen';
Observable.prototype.delayWhen = delayWhen;
//# sourceMappingURL=delayWhen.js.map