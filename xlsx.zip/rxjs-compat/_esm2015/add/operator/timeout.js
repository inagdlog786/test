import { Observable } from 'rxjs';
import { timeout } from '../../operator/timeout';
Observable.prototype.timeout = timeout;
//# sourceMappingURL=timeout.js.map