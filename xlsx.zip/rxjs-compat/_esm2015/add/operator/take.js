import { Observable } from 'rxjs';
import { take } from '../../operator/take';
Observable.prototype.take = take;
//# sourceMappingURL=take.js.map