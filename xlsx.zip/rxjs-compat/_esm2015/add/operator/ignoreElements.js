import { Observable } from 'rxjs';
import { ignoreElements } from '../../operator/ignoreElements';
Observable.prototype.ignoreElements = ignoreElements;
//# sourceMappingURL=ignoreElements.js.map