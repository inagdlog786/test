import { Observable } from 'rxjs';
import { skipLast } from '../../operator/skipLast';
Observable.prototype.skipLast = skipLast;
//# sourceMappingURL=skipLast.js.map