import { Observable } from 'rxjs';
import { _do } from '../../operator/do';
Observable.prototype.do = _do;
Observable.prototype._do = _do;
//# sourceMappingURL=do.js.map