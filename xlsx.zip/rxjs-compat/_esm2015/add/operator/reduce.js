import { Observable } from 'rxjs';
import { reduce } from '../../operator/reduce';
Observable.prototype.reduce = reduce;
//# sourceMappingURL=reduce.js.map