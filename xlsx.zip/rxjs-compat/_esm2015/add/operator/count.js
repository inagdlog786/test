import { Observable } from 'rxjs';
import { count } from '../../operator/count';
Observable.prototype.count = count;
//# sourceMappingURL=count.js.map