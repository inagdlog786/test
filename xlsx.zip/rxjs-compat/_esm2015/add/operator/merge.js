import { Observable } from 'rxjs';
import { merge } from '../../operator/merge';
Observable.prototype.merge = merge;
//# sourceMappingURL=merge.js.map