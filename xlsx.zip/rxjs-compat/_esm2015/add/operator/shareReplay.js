import { Observable } from 'rxjs';
import { shareReplay } from '../../operator/shareReplay';
Observable.prototype.shareReplay = shareReplay;
//# sourceMappingURL=shareReplay.js.map