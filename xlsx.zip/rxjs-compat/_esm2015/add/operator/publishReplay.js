import { Observable } from 'rxjs';
import { publishReplay } from '../../operator/publishReplay';
Observable.prototype.publishReplay = publishReplay;
//# sourceMappingURL=publishReplay.js.map