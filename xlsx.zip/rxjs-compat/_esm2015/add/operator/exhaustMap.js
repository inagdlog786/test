import { Observable } from 'rxjs';
import { exhaustMap } from '../../operator/exhaustMap';
Observable.prototype.exhaustMap = exhaustMap;
//# sourceMappingURL=exhaustMap.js.map