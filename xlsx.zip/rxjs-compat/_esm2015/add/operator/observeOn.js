import { Observable } from 'rxjs';
import { observeOn } from '../../operator/observeOn';
Observable.prototype.observeOn = observeOn;
//# sourceMappingURL=observeOn.js.map