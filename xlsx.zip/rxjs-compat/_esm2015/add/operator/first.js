import { Observable } from 'rxjs';
import { first } from '../../operator/first';
Observable.prototype.first = first;
//# sourceMappingURL=first.js.map