import { Observable } from 'rxjs';
import { windowToggle } from '../../operator/windowToggle';
Observable.prototype.windowToggle = windowToggle;
//# sourceMappingURL=windowToggle.js.map