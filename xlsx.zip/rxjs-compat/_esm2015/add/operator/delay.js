import { Observable } from 'rxjs';
import { delay } from '../../operator/delay';
Observable.prototype.delay = delay;
//# sourceMappingURL=delay.js.map