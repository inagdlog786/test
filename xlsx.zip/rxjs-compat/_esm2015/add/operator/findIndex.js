import { Observable } from 'rxjs';
import { findIndex } from '../../operator/findIndex';
Observable.prototype.findIndex = findIndex;
//# sourceMappingURL=findIndex.js.map