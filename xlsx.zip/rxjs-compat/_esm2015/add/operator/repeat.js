import { Observable } from 'rxjs';
import { repeat } from '../../operator/repeat';
Observable.prototype.repeat = repeat;
//# sourceMappingURL=repeat.js.map