import { Observable } from 'rxjs';
import { windowWhen } from '../../operator/windowWhen';
Observable.prototype.windowWhen = windowWhen;
//# sourceMappingURL=windowWhen.js.map