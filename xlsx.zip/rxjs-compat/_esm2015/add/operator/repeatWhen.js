import { Observable } from 'rxjs';
import { repeatWhen } from '../../operator/repeatWhen';
Observable.prototype.repeatWhen = repeatWhen;
//# sourceMappingURL=repeatWhen.js.map