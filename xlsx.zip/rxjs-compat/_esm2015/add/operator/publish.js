import { Observable } from 'rxjs';
import { publish } from '../../operator/publish';
Observable.prototype.publish = publish;
//# sourceMappingURL=publish.js.map