import { Observable } from 'rxjs';
import { scan } from '../../operator/scan';
Observable.prototype.scan = scan;
//# sourceMappingURL=scan.js.map