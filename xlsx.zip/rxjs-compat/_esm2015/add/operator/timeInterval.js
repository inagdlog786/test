import { Observable } from 'rxjs';
import { timeInterval } from '../../operator/timeInterval';
Observable.prototype.timeInterval = timeInterval;
//# sourceMappingURL=timeInterval.js.map