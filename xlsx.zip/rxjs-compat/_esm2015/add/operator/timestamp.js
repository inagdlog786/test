import { Observable } from 'rxjs';
import { timestamp } from '../../operator/timestamp';
Observable.prototype.timestamp = timestamp;
//# sourceMappingURL=timestamp.js.map