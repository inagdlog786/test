import { Observable } from 'rxjs';
import { timeoutWith } from '../../operator/timeoutWith';
Observable.prototype.timeoutWith = timeoutWith;
//# sourceMappingURL=timeoutWith.js.map