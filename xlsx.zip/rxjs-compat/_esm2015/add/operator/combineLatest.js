import { Observable } from 'rxjs';
import { combineLatest } from '../../operator/combineLatest';
Observable.prototype.combineLatest = combineLatest;
//# sourceMappingURL=combineLatest.js.map