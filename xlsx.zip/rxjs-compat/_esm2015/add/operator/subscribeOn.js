import { Observable } from 'rxjs';
import { subscribeOn } from '../../operator/subscribeOn';
Observable.prototype.subscribeOn = subscribeOn;
//# sourceMappingURL=subscribeOn.js.map