import { Observable } from 'rxjs';
import { mapTo } from '../../operator/mapTo';
Observable.prototype.mapTo = mapTo;
//# sourceMappingURL=mapTo.js.map