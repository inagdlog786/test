import { Observable } from 'rxjs';
import { onErrorResumeNext } from '../../operator/onErrorResumeNext';
Observable.prototype.onErrorResumeNext = onErrorResumeNext;
//# sourceMappingURL=onErrorResumeNext.js.map