import { Observable } from 'rxjs';
import { expand } from '../../operator/expand';
Observable.prototype.expand = expand;
//# sourceMappingURL=expand.js.map