import { Observable } from 'rxjs';
import { pluck } from '../../operator/pluck';
Observable.prototype.pluck = pluck;
//# sourceMappingURL=pluck.js.map