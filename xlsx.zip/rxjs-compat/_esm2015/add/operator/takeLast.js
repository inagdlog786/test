import { Observable } from 'rxjs';
import { takeLast } from '../../operator/takeLast';
Observable.prototype.takeLast = takeLast;
//# sourceMappingURL=takeLast.js.map