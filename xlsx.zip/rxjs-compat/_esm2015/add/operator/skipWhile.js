import { Observable } from 'rxjs';
import { skipWhile } from '../../operator/skipWhile';
Observable.prototype.skipWhile = skipWhile;
//# sourceMappingURL=skipWhile.js.map