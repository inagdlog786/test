import { Observable } from 'rxjs';
import { partition } from '../../operator/partition';
Observable.prototype.partition = partition;
//# sourceMappingURL=partition.js.map