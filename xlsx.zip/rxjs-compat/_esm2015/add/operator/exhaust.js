import { Observable } from 'rxjs';
import { exhaust } from '../../operator/exhaust';
Observable.prototype.exhaust = exhaust;
//# sourceMappingURL=exhaust.js.map