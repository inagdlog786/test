import { Observable } from 'rxjs';
import { max } from '../../operator/max';
Observable.prototype.max = max;
//# sourceMappingURL=max.js.map