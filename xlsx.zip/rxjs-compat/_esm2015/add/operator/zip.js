import { Observable } from 'rxjs';
import { zipProto } from '../../operator/zip';
Observable.prototype.zip = zipProto;
//# sourceMappingURL=zip.js.map