import { Observable, of as staticOf } from 'rxjs';
Observable.of = staticOf;
//# sourceMappingURL=of.js.map