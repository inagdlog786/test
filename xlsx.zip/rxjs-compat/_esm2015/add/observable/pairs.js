import { Observable, pairs as staticPairs } from 'rxjs';
Observable.pairs = staticPairs;
//# sourceMappingURL=pairs.js.map