import { Observable, from } from 'rxjs';
Observable.fromPromise = from;
//# sourceMappingURL=fromPromise.js.map