import { Observable, race as staticRace } from 'rxjs';
Observable.race = staticRace;
//# sourceMappingURL=race.js.map