import { Observable, interval as staticInterval } from 'rxjs';
Observable.interval = staticInterval;
//# sourceMappingURL=interval.js.map