import { Observable, range as staticRange } from 'rxjs';
Observable.range = staticRange;
//# sourceMappingURL=range.js.map