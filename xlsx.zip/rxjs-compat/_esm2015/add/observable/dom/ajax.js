import { Observable } from 'rxjs';
import { ajax as staticAjax } from 'rxjs/ajax';
Observable.ajax = staticAjax;
//# sourceMappingURL=ajax.js.map