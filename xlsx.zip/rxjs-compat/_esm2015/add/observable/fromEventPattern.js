import { Observable, fromEventPattern as staticFromEventPattern } from 'rxjs';
Observable.fromEventPattern = staticFromEventPattern;
//# sourceMappingURL=fromEventPattern.js.map