import { Observable, from as staticFrom } from 'rxjs';
Observable.from = staticFrom;
//# sourceMappingURL=from.js.map