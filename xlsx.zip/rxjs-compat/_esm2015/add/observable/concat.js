import { Observable, concat as concatStatic } from 'rxjs';
Observable.concat = concatStatic;
//# sourceMappingURL=concat.js.map