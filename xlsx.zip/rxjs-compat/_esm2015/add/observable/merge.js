import { Observable, merge as mergeStatic } from 'rxjs';
Observable.merge = mergeStatic;
//# sourceMappingURL=merge.js.map