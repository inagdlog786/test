import { Observable, timer as staticTimer } from 'rxjs';
Observable.timer = staticTimer;
//# sourceMappingURL=timer.js.map