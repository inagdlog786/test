import { Observable, bindNodeCallback as staticBindNodeCallback } from 'rxjs';
Observable.bindNodeCallback = staticBindNodeCallback;
//# sourceMappingURL=bindNodeCallback.js.map