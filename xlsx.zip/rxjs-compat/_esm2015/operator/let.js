export function letProto(func) {
    return func(this);
}
//# sourceMappingURL=let.js.map