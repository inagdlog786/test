import { isEmpty as higherOrder } from 'rxjs/operators';
export function isEmpty() {
    return higherOrder()(this);
}
//# sourceMappingURL=isEmpty.js.map