import { concatAll as higherOrder } from 'rxjs/operators';
export function concatAll() {
    return higherOrder()(this);
}
//# sourceMappingURL=concatAll.js.map