import { ignoreElements as higherOrder } from 'rxjs/operators';
export function ignoreElements() {
    return higherOrder()(this);
}
//# sourceMappingURL=ignoreElements.js.map