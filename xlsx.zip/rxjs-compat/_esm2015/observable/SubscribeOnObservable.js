export { SubscribeOnObservable } from 'rxjs/internal-compatibility';
//# sourceMappingURL=SubscribeOnObservable.js.map