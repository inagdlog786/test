export { WebSocketSubject } from 'rxjs/internal-compatibility';
//# sourceMappingURL=WebSocketSubject.js.map