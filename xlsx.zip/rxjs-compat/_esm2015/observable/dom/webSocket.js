export { webSocket } from 'rxjs/internal-compatibility';
//# sourceMappingURL=webSocket.js.map