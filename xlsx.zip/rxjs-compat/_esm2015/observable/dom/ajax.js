export { ajax } from 'rxjs/internal-compatibility';
//# sourceMappingURL=ajax.js.map