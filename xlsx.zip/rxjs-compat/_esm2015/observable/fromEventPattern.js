export { fromEventPattern } from 'rxjs';
//# sourceMappingURL=fromEventPattern.js.map