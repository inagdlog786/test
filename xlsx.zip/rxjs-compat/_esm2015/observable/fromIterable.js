export { fromIterable } from 'rxjs/internal-compatibility';
//# sourceMappingURL=fromIterable.js.map