export { pairs } from 'rxjs';
//# sourceMappingURL=pairs.js.map