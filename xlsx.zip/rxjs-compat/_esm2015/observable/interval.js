export { interval } from 'rxjs';
//# sourceMappingURL=interval.js.map