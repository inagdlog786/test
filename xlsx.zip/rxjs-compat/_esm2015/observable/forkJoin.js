export { forkJoin } from 'rxjs';
//# sourceMappingURL=forkJoin.js.map