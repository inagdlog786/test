import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpModule, Http , Response, Headers } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { MaterialModule } from './material.module';

// import { throwError } from 'rxjs';
// import { Observable } from 'rxjs';
// import { catchError } from 'rxjs/operators';

import { NgxPopper } from 'angular-popper';

import { AppComponent } from './app.component';
import { GridComponent } from './grid/grid.component';
import { TestComponent } from './test/test.component';
import { CfilterPipe } from './test/cfilter.pipe';
import { ExpandComponent } from './expand/expand.component';
import { NgxtableComponent } from './ngxtable/ngxtable.component';
// import { Ng2expandComponent } from './ng2expand/ng2expand.component';

import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { NgxdemoComponent } from './ngxdemo/ngxdemo.component';

const appRoutes: Routes = [
  { path: '', component: GridComponent},
  { path: 'test', component: TestComponent},
  { path: 'demo', component: ExpandComponent},
  { path: 'demo1', component: NgxtableComponent},
  { path: 'demo2', component: NgxdemoComponent}
  // { path: 'demo1', component: Ng2expandComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    GridComponent,
    TestComponent,
    CfilterPipe,
    ExpandComponent,
    NgxtableComponent,
    NgxdemoComponent,
    // Ng2expandComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoutes),
    HttpModule,
    HttpClientModule,
    MaterialModule,
    NgxPopper,
    NgxDatatableModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
