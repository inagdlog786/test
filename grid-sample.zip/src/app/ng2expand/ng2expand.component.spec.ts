import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ng2expandComponent } from './ng2expand.component';

describe('Ng2expandComponent', () => {
  let component: Ng2expandComponent;
  let fixture: ComponentFixture<Ng2expandComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ng2expandComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ng2expandComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
