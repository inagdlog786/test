import { Component, OnInit } from '@angular/core';
import {animate, state, style, transition, trigger} from '@angular/animations';

export interface Transaction {
  item: string;
  cost: number;
  symbol: string;
  position: number;
}

@Component({
  selector: 'app-expand',
  templateUrl: './expand.component.html',
  styleUrls: ['./expand.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0', display: 'none'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class ExpandComponent implements OnInit {
  dataSource = ELEMENT_DATA;
  columnsToDisplay = ['name', 'rate', 'symbol', 'position'];
  expandedElement: Transaction;

  displayedColumns: string[] = ['symbol', 'cost', 'item', 'position'];
  transactions: Transaction[] = [
    {symbol: 'H', item: 'Beach ball', cost: 4, position: 1},
    {symbol: 'He', item: 'Towel', cost: 5, position: 1},
    {symbol: 'Li', item: 'Frisbee', cost: 2, position: 1}
  ];

  /** Gets the total cost of all transactions. */
  getTotalCost() {
    return this.transactions.map(t => t.cost).reduce((acc, value) => acc + value, 0);
  }

  constructor() { }

  ngOnInit() {
  }

}
export interface PeriodicElement {
  name: string;
  position: number;
  rate: number;
  symbol: string;
  description: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {
    position: 1,
    name: 'Hydrogen',
    rate: 1.0079,
    symbol: 'H',
    description: `test.html`
  }, {
    position: 2,
    name: 'Helium',
    rate: 4.0026,
    symbol: 'He',
    description: `Helium is a chemical element with symbol He and atomic number 2. It is a
        colorless, odorless, tasteless, non-toxic, inert, monatomic gas, the first in the noble gas
        group in the periodic table. Its boiling point is the lowest among all the elements.`
  }, {
    position: 3,
    name: 'Lithium',
    rate: 6.941,
    symbol: 'Li',
    description: `Lithium is a chemical element with symbol Li and atomic number 3. It is a soft,
        silvery-white alkali metal. Under standard conditions, it is the lightest metal and the
        lightest solid element.`
  }
];
