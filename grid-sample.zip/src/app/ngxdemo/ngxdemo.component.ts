import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-ngxdemo',
  templateUrl: './ngxdemo.component.html',
  styleUrls: ['./ngxdemo.component.css']
})
export class NgxdemoComponent implements OnInit {
  // editing = {};
  // rows = [
  //   { name: 'Austin', gender: 'Male', company: 'Swimlane', test: 'demo1' },
  //   { name: 'Dany', gender: 'Male', company: 'KFC', test: 'demo2' },
  //   { name: 'Molly', gender: 'Female', company: 'Burger King', test: 'demo3' },
  // ];
  // columns = [
  //   { prop: 'name' },
  //   { name: 'Gender' },
  //   { name: 'Company' },
  //   { name: 'test'}
  // ];


  // constructor() { }

  @ViewChild('mydatatable') table: any;

  groups = [];
  editing = {};
  rows = [
    {
      name: 'Laptop',
      rate: 2230,
      purchase: 2000
  },
  {
    name: 'Laptop',
      rate: 5200,
      purchase: 2500
  },
  {
    name: 'Desktop',
    rate: 4200,
    purchase: 2200
},
{
  name: 'Desktop',
  rate: 6200,
  purchase: 3300
},
  ];

  constructor() {
    // this.fetch((data) => {
    //   this.rows = data;
    // });
  }

  // fetch(cb) {
  //   const req = new XMLHttpRequest();
  //   req.open('GET', 'assets/data/company.json');

  //   req.onload = () => {
  //     cb(JSON.parse(req.response));
  //   };

  //   req.send();
  // }

  getGroupRowHeight(group, rowHeight) {
    let style = {};

    style = {
      height: (group.length * 40) + 'px',
      width: '100%'
    };

    return style;
  }


  updateValue(event, cell, rowIndex) {
    console.log('inline editing rowIndex', rowIndex);
    this.editing[rowIndex + '-' + cell] = false;
    this.rows[rowIndex][cell] = event.target.value;
    this.rows = [...this.rows];
    console.log('UPDATED!', this.rows[rowIndex][cell]);
  }

  toggleExpandGroup(group) {
    console.log('Toggled Expand Group!', group);
    this.table.groupHeader.toggleExpandGroup(group);
  }
  onDetailToggle(event) {
    console.log('Detail Toggled', event);
  }


  ngOnInit() {
  }

}
