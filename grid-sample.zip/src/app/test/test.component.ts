import { Component, OnInit } from '@angular/core';
import { MatTableDataSource, MatListItem } from '@angular/material';
import { NgModule } from '@angular/core';
import { Pipe, PipeTransform } from '@angular/core';
import { CfilterPipe } from './cfilter.pipe';
export interface Transaction {
  item: string;
  cost: number;
  test: string;
}
@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  filter = {
    field: '',
    criteria: '',
    filtervalue: ''
  };

  displayedColumns: string[] = ['item', 'cost', 'test'];
  filterCnt: string;
  transactions: Transaction[] = [
    { item: 'Laptop', cost: 4, test: 'Sample' },
    { item: 'Laptop', cost: 4, test: 'Sample' },
    { item: 'Desktop', cost: 4, test: 'Sample' },
    { item: 'Desktop', cost: 4, test: 'Sample' }
  ];

  dataSource = new MatTableDataSource(this.transactions);
  /** Gets the total cost of all transactions. */
  getTotalCost() {
    if (this.filterCnt == null) {
      return this.transactions.map(t => t.cost).reduce((acc, value) => acc + value, 0);
      } else  {
        return this.transactions.filter(
          (task) => task.item.toLowerCase().startsWith(
                this.filterCnt.toLowerCase())).map(t => t.cost).reduce((acc, value) => acc + value, 0);
    }
  }
  applyFilter(filterValue: string) {
    this.filterCnt = filterValue;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  filterData() {

  }

  constructor() { }

  ngOnInit() {
  }

}
