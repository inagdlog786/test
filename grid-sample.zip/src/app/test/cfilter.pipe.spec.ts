import { CfilterPipe } from './cfilter.pipe';

describe('CfilterPipe', () => {
  it('create an instance', () => {
    const pipe = new CfilterPipe();
    expect(pipe).toBeTruthy();
  });
});
