import { Component, OnInit } from '@angular/core';
import { MatTableDataSource, MatListItem } from '@angular/material';

export interface Transaction {
  item: string;
  cost: number;
  test: string;
}
@Component({
  selector: 'app-devextreme-test',
  templateUrl: './devextreme-test.component.html',
  styleUrls: ['./devextreme-test.component.css']
})
export class DevextremeTestComponent implements OnInit {


  displayedColumns: string[] = ['item', 'cost', 'test'];
  filterCnt: string;
  transactions: Transaction[] = [
    { item: 'Laptop', cost: 4, test: 'Sample' },
    { item: 'Laptop', cost: 4, test: 'Sample' },
    { item: 'Desktop', cost: 4, test: 'Sample' },
    { item: 'Desktop', cost: 4, test: 'Sample' }
  ];

  dataSource = new MatTableDataSource(this.transactions);
  /** Gets the total cost of all transactions. */
  getTotalCost() {


    if (this.filterCnt == null) {
      return this.transactions.map(t => t.cost).reduce((acc, value) => acc + value, 0);
      } else  {
        return this.transactions.filter(
          (task) => task.item.toLowerCase().startsWith(
                this.filterCnt.toLowerCase())).map(t => t.cost).reduce((acc, value) => acc + value, 0);
    }
  }



  applyFilter(filterValue: string) {
    this.filterCnt = filterValue;
    this.dataSource = new MatTableDataSource(
      this.transactions.filter(rec => rec.item.toLocaleLowerCase().startsWith(filterValue.toLocaleLowerCase())));
  }

  constructor() { }

  ngOnInit() {
  }


}
