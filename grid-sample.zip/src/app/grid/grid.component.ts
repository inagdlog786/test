import { Component, OnInit } from '@angular/core';
import { MatTableDataSource, MatListItem } from '@angular/material';
import { NgModule } from '@angular/core';
import {FormControl} from '@angular/forms';
import {map} from 'rxjs/operators';

export interface Transaction {
  item: string;
  cost: number;
  test: string;
}
@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css']
})
export class GridComponent implements OnInit {

  displayedColumns: string[] = ['item', 'cost', 'test'];
  filterCnt: string;
  // transaction = new FormControl();
  transactions: Transaction[] = [
    { item: 'Laptop', cost: 4, test: 'Sample' },
    { item: 'Laptop', cost: 4, test: 'Sample' },
    { item: 'Desktop', cost: 4, test: 'Sample' },
    { item: 'Desktop', cost: 4, test: 'Sample' }
  ];
  dataMap = new Map<string, Transaction[]>([
    ['Laptop', [{ item: 'Laptop', cost: 4, test: 'Sample' }, { item: 'Laptop', cost: 4, test: 'Sample' }]],
    ['Desktop', [ { item: 'Desktop', cost: 4, test: 'Sample' }, { item: 'Desktop', cost: 4, test: 'Sample' }]],
  ]);

  dataSource = new MatTableDataSource(this.transactions);
  /** Gets the total cost of all transactions. */
  getTotalCost() {


    if (this.filterCnt == null) {
      return this.transactions.map(t => t.cost).reduce((acc, value) => acc + value, 0);
      } else  {
        return this.transactions.filter(
          (task) => task.item.toLowerCase().startsWith(
                this.filterCnt.toLowerCase())).map(t => t.cost).reduce((acc, value) => acc + value, 0);
    }
  }



  applyFilter(filterValue: string) {
    this.filterCnt = filterValue;

    this.dataSource = new MatTableDataSource(
      this.transactions.filter(rec => rec.item.toLocaleLowerCase().startsWith(filterValue.toLocaleLowerCase())));

      for (let i = 0; i < this.transactions.length; i++) {
        console.log(this.transactions[i]);
        const item = this.transactions[i];

        if ( this.transactions[i].item) {

        }


      }
  }

  constructor() { }

  ngOnInit() {
  }

}
