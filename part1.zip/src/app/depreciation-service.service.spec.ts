import { TestBed, inject } from '@angular/core/testing';

import { DepreciationServiceService } from './depreciation-service.service';

describe('DepreciationServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DepreciationServiceService]
    });
  });

  it('should be created', inject([DepreciationServiceService], (service: DepreciationServiceService) => {
    expect(service).toBeTruthy();
  }));
});
