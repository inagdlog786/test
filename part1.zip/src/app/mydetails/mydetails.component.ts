import { Component, OnInit } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FormBuilder, FormGroup, Validators, FormControl, EmailValidator } from '@angular/forms';
import {ErrorStateMatcher} from '@angular/material/core';
import { VERSION } from '@angular/platform-browser-dynamic';
import {MomentDateAdapter} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
import {MatDatepicker} from '@angular/material/datepicker';


import {MatIconModule} from '@angular/material/icon';
import { MatDialog } from '@angular/material';
import { ModalComponent } from '../modal/modal.component';

import * as _moment from 'moment';
import {default as _rollupMoment, Moment} from 'moment';
import { config } from 'rxjs';

const moment = _rollupMoment || _moment;
export interface Ccode {
  value: String;
  viewValue: String;
}
export const MY_FORMATS = {
  parse: {
    dateInput: 'MM/YYYY',
  },
  display: {
    dateInput: 'MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-mydetails',
  templateUrl: './mydetails.component.html',
  styleUrls: ['./mydetails.component.css'],
  providers: [
    // `MomentDateAdapter` can be automatically provided by importing `MomentDateModule` in your
    // application's root module. We provide it at the component level here, due to limitations of
    // our example generation script.
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},

    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ],
})



export class MydetailsComponent implements OnInit {

  animal: string;
  name: string;

  // Validation
  email = new FormControl('', [Validators.required, Validators.email]);

  // form name
  scrollValidation: FormGroup;

  // selectbox
  ccodes: Ccode[] = [
    {value: 'RCP-0', viewValue: 'Phase01'},
    {value: 'RCP-1', viewValue: 'Phase02'},
    {value: 'RCP-2', viewValue: 'Phase03'}
  ];

  // Date
  date = new FormControl(moment());

  chosenYearHandler(normalizedYear: Moment) {
    const ctrlValue = this.date.value;
    ctrlValue.year(normalizedYear.year());
    this.date.setValue(ctrlValue);
  }


  getErrorMessage() {
    return this.email.hasError('required') ? 'You must enter a value' :
        this.email.hasError('email') ? 'Not a valid email' :
            '';
  }

  constructor(
    public dialog: MatDialog,
    // Form
    private formBuilder: FormBuilder
  ) {this.createScrollValidationForm(); }

  private createScrollValidationForm() {
    this.scrollValidation = this.formBuilder.group({
      companyCode: [''],
      selectDate: [''],
      scrollNumberFrom: [''],
      scrollNumberTo: [''],
      scrollDateFrom: [''],
      scrollDateTo: [''],
      ApLocationFrom: [''],
      ApLocationTo: [''],
    });
  }

  ngOnInit() {
  }

  handleSubmit() {
    console.log(this.scrollValidation);
  }
  public openModal() {
    this.dialog.open(ModalComponent);
  }
}
