import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdditionalcreteriaComponent } from './additionalcreteria.component';

describe('AdditionalcreteriaComponent', () => {
  let component: AdditionalcreteriaComponent;
  let fixture: ComponentFixture<AdditionalcreteriaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdditionalcreteriaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdditionalcreteriaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
