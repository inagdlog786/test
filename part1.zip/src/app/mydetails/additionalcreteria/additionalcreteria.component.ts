import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-additionalcreteria',
  templateUrl: './additionalcreteria.component.html',
  styleUrls: ['./additionalcreteria.component.css']
})
export class AdditionalcreteriaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
