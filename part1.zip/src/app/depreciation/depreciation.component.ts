import { SelectionModel } from '@angular/cdk/collections';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatSort, MatPaginator, MatTableDataSource, MatDialog } from '@angular/material';
import { CurrencyIndex } from '@angular/common/src/i18n/locale_data';
import { ModalComponent } from '../modal/modal.component';
import { AdddeductionComponent } from '../vre/adddeduction/adddeduction.component';
import { CalculateAmountEligibleComponent } from '../vre/calculate-amount-eligible/calculate-amount-eligible.component';
import { SatDatepickerRangeValue, SatDatepickerInputEvent } from 'saturn-datepicker';

import { DepreciationServiceService } from '../depreciation-service.service';

import {
  HttpClient, HttpClientModule, HttpResponse, HttpRequest,
  HttpEventType, HttpErrorResponse, HttpHeaders
} from '@angular/common/http';
import { Http, Response, ResponseType } from "@angular/http";
import { Observable, of, throwError, pipe } from 'rxjs';
import { map, filter, catchError, mergeMap } from 'rxjs/operators';

import { trigger, state, style, animate, transition } from '@angular/animations';


import { NgModule } from '@angular/core';
import { DpothersComponent } from './dpothers/dpothers.component';

import { IDepreciation } from '../depreciation/IDepreciation';

import * as XLSX from 'xlsx';
import { splitClasses } from '../../../node_modules/@angular/compiler';

//const ELEMENT_DATA:IDepreciation[]= null;


const ELEMENT_DATA = null;
//: IDepreciation[] ;
// = 
// [
//   {

//     entity: 'Entity1',
//     from_date: '01.11.2018',
//     to_date: '01.11.2018',  
//     id: 1,
//     assets: 'test1',
//     rate: 22,
//     assets_depn:1,
//     other_assets:2,
//     purchase_val: 3,
//     cenvat_adjustment: 4,
//     forex_adjustment: 5,
//     subsidy_adjustment: 6,
//     tot_purchase:7,
//     purchase_lessdays: 8,
//     cenvat_lessdays: 9,
//     forex_lessdays: 10,
//     subsidy_lessdays: 20,
//     totpurchase_purchase: 30,
//     assets_moredays: 40,
//     assets_lessdays: 50,
//     dep_fullrate: 60,
//     dep_halfrate: 70,
//     fullrate: 80,
//     halfrate: 90,
//     cyassets_moredays: 10,
//     cyassets_lessdays:20,
//     pre_yr_lessdays: 10,
//     tot_dep: 10,
//     disallow_dep: 11,
//     aggre_dep: 12,
//     allowable: 13,
//     expenditure: 14,
//     gainloss_sec50: 15,
//     val_eoy: 16,
//     status:'Pending',
//     remarks: 'NA',
//     action: 'NA'
//   },
//   { 
//     entity: 'Entity2',
//     from_date: '01.12.2018',
//     to_date: '01.12.2018',  
//     id: 3,
//     assets: 'test2',
//     rate: 33,
//     assets_depn: 20,
//     other_assets:21,
//     purchase_val: 22,
//     cenvat_adjustment: 23,
//     forex_adjustment: 24,
//     subsidy_adjustment: 25,
//     tot_purchase: 26,
//     purchase_lessdays: 27,
//     cenvat_lessdays: 28,
//     forex_lessdays: 29,
//     subsidy_lessdays: 30,
//     totpurchase_purchase: 19,
//     assets_moredays: 0,
//     assets_lessdays: 0,
//     dep_fullrate: 0,
//     dep_halfrate: 0,
//     fullrate: 0,
//     halfrate: 0,
//     cyassets_moredays: 0,
//     cyassets_lessdays: 0,
//     pre_yr_lessdays: 0,
//     tot_dep: 20,
//     disallow_dep: 21,
//     aggre_dep: 22,
//     allowable: 23,
//     expenditure: 24,
//     gainloss_sec50: 25,
//     val_eoy: 26,
//     status:'Pending',
//     remarks: 'NA',
//     action: 'NA'
//  }

//];



@Component({
  selector: 'app-depreciation',
  templateUrl: './depreciation.component.html',
  styleUrls: ['./depreciation.component.css'],
  providers: [DepreciationServiceService]

})

// export class DepreciationComponent implements OnInit {displayedColumns: string[] = ['select', 'position', 'servername', 'compnaycode',
// 'documentnumber', 'trdate',
// 'action'
// ];

export class DepreciationComponent implements OnInit {
  
  displayedColumns: string[] = ['select', 'id', 'assets', 'rate',
    'tot_dep', 'disallow_dep', 'aggre_dep',
    'allowable', 'expenditure', 'gainloss_sec50', 'val_eoy', 'action'];
  arrayBuffer: any;
  file: File;
  public depreciation = [];


  dataSource = new MatTableDataSource();


  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  selection = new SelectionModel<IDepreciation>(true, []);

  alert: boolean = false;
  errorMessage: string = "success";
  errorStyle: string = "alert-success";

  // Date Range
  date: SatDatepickerRangeValue<Date>;
  lastDateInput: SatDatepickerRangeValue<Date> | null;
  lastDateChange: SatDatepickerRangeValue<Date> | null;
  ourfile: File;
  onDateInput = (e: SatDatepickerInputEvent<Date>) => this.lastDateInput = e.value as SatDatepickerRangeValue<Date>;
  onDateChange = (e: SatDatepickerInputEvent<Date>) => this.lastDateChange = e.value as SatDatepickerRangeValue<Date>;

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  openInput() {
    document.getElementById("fileinput").click();
  }

  filechange(file: File[]) {
    if (file.length > 0) {
      this.ourfile = file[0];
    }
  }

  upload() {
    console.log('sending this file to server', this.ourfile);
    let filesData = this.ourfile.name;
    const url = 'your-destination-url';
    const formData: FormData = new FormData();
    formData.append('fileKey', filesData, filesData);

    this.http.post('http:localhost:3000/upload', filesData).subscribe(
      (result) => {
        console.log("success!");
        //this.depreciation = result;
      },
      (err) => {
        console.log(JSON.stringify(err));
      }
    );
  }
  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    //   this.isAllSelected() ?
    //       this.selection.clear() :
    //      this.dataSource.data.forEach(row => this.selection.select(row));
  }

  ApiCall() {

    this.http.get('/assets/data/depreciation.json').subscribe(data => {
      console.log(data);
    });
  }
  public show: boolean = false;
  public buttonName: any = 'Show';




  public uploadData(event: any): void {
    // get data from file upload       
    //   let filesData = event.target.files;
    //   const url = 'your-destination-url';
    //   const formData: FormData = new FormData();
    //   formData.append('fileKey', filesData, filesData.name);

    //   this.http.post('http:localhost:3000/upload', filesData).subscribe(
    //   (result) => {
    //     console.log("success!");
    //     //this.depreciation = result;
    //   },
    //   (err) => {
    //     console.log(JSON.stringify(err));
    //   }
    // );



    //return this.http.post('/upload', filesData)
    // .success(function (res) {

    // return this.http.post(url,filesData,{ headers: null })
    // .map(() => { return true; })
    //.catch((e) => this.handleError(e));

    //return this.http.post(url,filesData,{
    //responseType:'blob',
    //headers:new HttpHeaders('content-type','application/json')
    //})

  }


  constructor(public CAE: MatDialog, private _depreciationService: DepreciationServiceService, private http: HttpClient) {
  }

  public openModal(dataSource: any, element: any) {

    // this.CAE.open(DpothersComponent),{
    //   width: '600px',
    //   data:element,
    // };
    debugger

    let dialogRef = this.CAE.open(DpothersComponent, {
      // data: {
      //   element: element
      // }
      data : element
    });

    dialogRef.afterClosed().subscribe(result => {
      debugger;
      this.depreciation = result;
      console.log(this.depreciation);

    });
    debugger;


  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }




  ngOnInit() {
    // debugger;
    this._depreciationService.getDepreciationData().subscribe(
      data => {
        // this.dataSource.data = data;
        console.log(this.dataSource.data);
      }
    );


    // this.dataSource.paginator = this.paginator;
    // this.dataSource.sort = this.sort;
  }

  uploadfile(event) {
    this.file = event.target.files[0];
    this.fupload();
  }
  fupload() {
    var excelData = [];
    let fileReader = new FileReader();
    fileReader.onload = (e) => {
      this.arrayBuffer = fileReader.result;
      var data = new Uint8Array(this.arrayBuffer);
      var arr = new Array();
      for (var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);
      var bstr = arr.join("");
      var workbook = XLSX.read(bstr, { type: "binary" });
      var first_sheet_name = workbook.SheetNames[0];
      var worksheet = workbook.Sheets[first_sheet_name];
      var excelData = XLSX.utils.sheet_to_json(worksheet, { raw: true })
      this.dataSource.data.concat(excelData);

      var DBdata = [];
      DBdata = excelData;
      debugger;
      for (var k = 0; k < DBdata.length; k++) {
        if (DBdata[k].assets != null && DBdata[k].id != null && DBdata[k].rate != null) {
          this.dataSource.data.push(DBdata[k]);
          this.alert = true;
          this.errorMessage = "success";
          this.errorStyle = "alert-success";
        }
        else if(DBdata.length==0){
          this.alert = true;          
          this.errorMessage = "No data Found";
          this.errorStyle = "alert-danger";
        }
        else {
          console.log("Error occured due to NOt available aasets");
          console.log(DBdata.length);
          this.alert = true;          
          this.errorMessage = "Warning occured due to Not available aasets";
          this.errorStyle = "alert-warning";
        }


      }
      this.dataSource = new MatTableDataSource(this.dataSource.data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;

    }
    fileReader.readAsArrayBuffer(this.file);
  }


  removeRow(dataSource: any, element: any) {
    var delObj = element;
    var tabData = this.dataSource.data;
    for (var z = 0; z < tabData.length; z++) {
      if (delObj.id === tabData[z].id) {
        let index: number = this.dataSource.data.findIndex(d => d === tabData[z]);

        this.dataSource.data.splice(index, 1);

        this.dataSource = new MatTableDataSource<Element>(this.dataSource.data);
      }
    }
    // var aftDeletion=this.dataSource.data.splice(ind,1);
    // this.dataSource = new MatTableDataSource(aftDeletion);
  }

  saveData() {
    // debugger;
    var dataToSend = this.dataSource.data;
    this._depreciationService.saveDataToDb(dataToSend).subscribe(res => {
      var response = res.body;
      console.log(response);
      this.alert = true;          
          this.errorMessage = "saved";
          this.errorStyle = "alert-success";
    },
      err => {
        this.alert = false;  
        this.alert = true;          
        this.errorMessage = "Duplicate Records Found";
        this.errorStyle = "alert-warning";
      }
    );
    // .subscribe((res)=>{
    // console.log(res);
    //res.toast({html:'saved succesfully',classes:'rounded'});
    //});
  }

  edit(element):void{
    console.log(element.id);
  }
  // toggle() {
  //   this.show = !this.show;
  //   if(this.show) 
  //   this.buttonName = "Hide";
  //   else
  //   this.buttonName = "Show";
  //   } 
}


