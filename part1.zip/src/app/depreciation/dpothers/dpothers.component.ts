import { Component, OnInit, Inject, ViewChild, Input, Output, EventEmitter, AfterViewInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DepreciationComponent } from '../depreciation.component';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';


export interface IDepreciation {
  entity: string,
  from_date: string,
  to_date: string
  id: number,
  assets: string,
  rate: number,
  assets_depn: number,
  other_assets: number,
  purchase_val: number,
  cenvat_adjustment: number,
  forex_adjustment: number,
  subsidy_adjustment: number,
  tot_purchase: number,
  purchase_lessdays: number,
  cenvat_lessdays: number,
  forex_lessdays: number,
  subsidy_lessdays: number,
  totpurchase_lessdays: number,
  assets_moredays: number,
  assets_lessdays: number,
  dep_fullrate: number,
  dep_halfrate: number,
  fullrate: number,
  halfrate: number,
  cyassets_moredays: number,
  cyassets_lessdays: number,
  pre_yr_lessdays: number,
  tot_dep: number,
  disallow_dep: number,
  aggre_dep: number,
  allowable: number,
  expenditure: number,
  gainloss_sec50: number,
  val_eoy: number,
  status: string,
  remarks: string,
  action: string
}

@Component({
  selector: 'app-dpothers',
  templateUrl: './dpothers.component.html',
  styleUrls: ['./dpothers.component.css']
})
export class DpothersComponent implements OnInit {
  model = {
    firstname: '', 
    lastname: ''
  }
  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  thirdFormGroup: FormGroup;
  fourFormGroup: FormGroup;
  fiveFormGroup: FormGroup;
  sixFormGroup: FormGroup;
  sevenFormGroup: FormGroup;
  testGroup: FormGroup;
  element: any;

  constructor(private _formBuilder: FormBuilder, public dialogRef: MatDialogRef<DepreciationComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {
    // this.element = data.element;
    dialogRef.disableClose = true;
  }

  closeDialog() {
    this.dialogRef.close();
  }

  ngOnInit() {
    this.createForm();
    // this.populateForm();
  }
  populateForm() {
    debugger
    this.firstFormGroup.get("assets_depn").setValue(this.element.assets_depn);
    this.firstFormGroup.get("other_assets").setValue(this.element.other_assets);

    this.secondFormGroup.get("purchase_val").setValue(this.element.purchase_val);
    this.secondFormGroup.get("cenvat_adjustment").setValue(this.element.cenvat_adjustment);
    this.secondFormGroup.get("forex_adjustment").setValue(this.element.forex_adjustment);
    this.secondFormGroup.get("subsidy_adjustment").setValue(this.element.subsidy_adjustment);
    this.secondFormGroup.get("tot_purchase").setValue(this.element.tot_purchase);

    this.thirdFormGroup.get("purchase_lessdays").setValue(this.element.purchase_lessdays);
    this.thirdFormGroup.get("cenvat_lessdays").setValue(this.element.cenvat_lessdays);
    this.thirdFormGroup.get("forex_lessdays").setValue(this.element.forex_lessdays);
    this.thirdFormGroup.get("subsidy_lessdays").setValue(this.element.subsidy_lessdays);
    this.thirdFormGroup.get("totpurchase_lessdays").setValue(this.element.tot_purchase );  

    this.fourFormGroup.get("assets_moredays").setValue(this.element.totpurchase_lessdays);
    this.fourFormGroup.get("assets_lessdays").setValue(this.element.assets_lessdays);

    this.fiveFormGroup.get("dep_fullrate").setValue(this.element.dep_fullrate);
    this.fiveFormGroup.get("dep_halfrate").setValue(this.element.dep_halfrate);

    this.sixFormGroup.get("fullrate").setValue(this.element.fullrate);
    this.sixFormGroup.get("halfrate").setValue(this.element.halfrate);

    this.sevenFormGroup.get("cyassets_moredays").setValue(this.element.cyassets_moredays);
    this.sevenFormGroup.get("cyassets_lessdays").setValue(this.element.cyassets_lessdays);
    this.sevenFormGroup.get("pre_yr_lessdays").setValue(this.element.pre_yr_lessdays);

  }

  createForm() {
    this.firstFormGroup = this._formBuilder.group({
      assets_depn: ['', Validators.required],
      other_assets: ['', Validators.required]
    });
    this.secondFormGroup = this._formBuilder.group({
        purchase_val    : ['', Validators.required],
        cenvat_adjustment: ['', Validators.required],
        forex_adjustment: ['', Validators.required],
        subsidy_adjustment: ['', Validators.required],
        tot_purchase: ['', Validators.required]
    });
    this.thirdFormGroup = this._formBuilder.group({
        purchase_lessdays: ['', Validators.required],
        cenvat_lessdays: ['', Validators.required],
        forex_lessdays: ['', Validators.required],
        subsidy_lessdays: ['', Validators.required],
        totpurchase_lessdays: ['', Validators.required]
    });
    this.fourFormGroup = this._formBuilder.group({
        assets_moredays: ['', Validators.required], 
        assets_lessdays: ['', Validators.required]
    });
    this.fiveFormGroup = this._formBuilder.group({
        dep_fullrate: ['', Validators.required],
        dep_halfrate: ['', Validators.required]
    });
    this.sixFormGroup = this._formBuilder.group({
        fullrate: ['', Validators.required],
        halfrate: ['', Validators.required]
    });
    this.sevenFormGroup = this._formBuilder.group({
        cyassets_moredays: ['', Validators.required],
        cyassets_lessdays: ['', Validators.required],
        pre_yr_lessdays: ['', Validators.required]
    });
  }
  updateOne(){
    debugger;
    console.log(this.firstFormGroup.value);
  }
  updateTwo(){
    console.log(this.secondFormGroup.value);
  }
  updateThree(){
    console.log(this.thirdFormGroup.value);
  }
  updateFour(){
    console.log(this.fourFormGroup.value);
  }
  updateFive(){
    console.log(this.fiveFormGroup.value);
  }
  updateSix(){
    console.log(this.sevenFormGroup.value);
  }
  updateSeven(){
    console.log(this.sevenFormGroup.value);
  }

}
