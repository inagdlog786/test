import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DpothersComponent } from './dpothers.component';

describe('DpothersComponent', () => {
  let component: DpothersComponent;
  let fixture: ComponentFixture<DpothersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DpothersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DpothersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
