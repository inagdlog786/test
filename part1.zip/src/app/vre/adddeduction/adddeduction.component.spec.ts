import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdddeductionComponent } from './adddeduction.component';

describe('AdddeductionComponent', () => {
  let component: AdddeductionComponent;
  let fixture: ComponentFixture<AdddeductionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdddeductionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdddeductionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
