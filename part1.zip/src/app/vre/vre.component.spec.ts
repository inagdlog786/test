import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VreComponent } from './vre.component';

describe('VreComponent', () => {
  let component: VreComponent;
  let fixture: ComponentFixture<VreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
