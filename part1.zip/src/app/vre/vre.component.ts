import {SelectionModel} from '@angular/cdk/collections';
import { Component, OnInit, ViewChild} from '@angular/core';
import {MatSort, MatPaginator, MatTableDataSource, MatDialog} from '@angular/material';
import { CurrencyIndex } from '@angular/common/src/i18n/locale_data';
import { ModalComponent } from '../modal/modal.component';
import { AdddeductionComponent } from './adddeduction/adddeduction.component';
import { CalculateAmountEligibleComponent } from './calculate-amount-eligible/calculate-amount-eligible.component';

export interface VoluntaryRetirementExpenses {
  servername: string;
  position: number;
  compnaycode: string;
  // symbol: string;

  documentnumber: number;
  trdate: String;
  glcode: number;
  glname: string;
  businessarea: String;
  profitcenter: String;
  unit: Number;
  amountcontributed: String;
  noyearofdeductionclaimed: Number;
  allowbleyears: Number;
  amounteligible: String;
  remarks: String;
  action: string;
}
const ELEMENT_DATA: VoluntaryRetirementExpenses[] = [
  {position: 1, servername: 'RP1', compnaycode: 'RIL1', documentnumber: 14235, trdate: '01.11.2018', glcode: 2324, glname: 'ABSC',
  businessarea: 'RCP',
  profitcenter: 'RIL',
  unit: 10,
  amountcontributed: '14790.00',
  noyearofdeductionclaimed: 3,
  allowbleyears: 5 ,
  amounteligible: 'NA',
  remarks: 'NA',
  action: 'NA',
  },
  {position: 2, servername: 'RP2', compnaycode: 'RIL2', documentnumber: 14200, trdate: '01.11.2018', glcode: 3535, glname: 'ABSC',
  businessarea: 'RCP1',
  profitcenter: 'RIL1',
  unit: 10,
  amountcontributed: '14790.00',
  noyearofdeductionclaimed: 3,
  allowbleyears: 5 ,
  amounteligible: 'NA',
  remarks: 'NA',
  action: 'NA',
  },
  {position: 3, servername: 'RP3', compnaycode: 'RIL3', documentnumber: 14200, trdate: '01.11.2018', glcode: 3535, glname: 'ABSC',
  businessarea: 'RCP1',
  profitcenter: 'RIL1',
  unit: 10,
  amountcontributed: '14790.00',
  noyearofdeductionclaimed: 3,
  allowbleyears: 5 ,
  amounteligible: 'NA',
  remarks: 'NA',
  action: 'NA',
  },
  {position: 4, servername: 'RP2', compnaycode: 'RIL2', documentnumber: 14200, trdate: '01.11.2018', glcode: 3535, glname: 'ABSC',
  businessarea: 'RCP1',
  profitcenter: 'RIL1',
  unit: 10,
  amountcontributed: '14790.00',
  noyearofdeductionclaimed: 3,
  allowbleyears: 5 ,
  amounteligible: 'NA',
  remarks: 'NA',
  action: 'NA',
  },
  {position: 5, servername: 'RP2', compnaycode: 'RIL2', documentnumber: 14200, trdate: '01.11.2018', glcode: 3535, glname: 'ABSC',
  businessarea: 'RCP1',
  profitcenter: 'RIL1',
  unit: 10,
  amountcontributed: '14790.00',
  noyearofdeductionclaimed: 3,
  allowbleyears: 5 ,
  amounteligible: 'NA',
  remarks: 'NA',
  action: 'NA',
  },
  {position: 6, servername: 'RP2', compnaycode: 'RIL2', documentnumber: 14200, trdate: '01.11.2018', glcode: 3535, glname: 'ABSC',
  businessarea: 'RCP1',
  profitcenter: 'RIL1',
  unit: 10,
  amountcontributed: '14790.00',
  noyearofdeductionclaimed: 3,
  allowbleyears: 5 ,
  amounteligible: 'NA',
  remarks: 'NA',
  action: 'NA',
  },
  {position: 7, servername: 'RP2', compnaycode: 'RIL2', documentnumber: 14200, trdate: '01.11.2018', glcode: 3535, glname: 'ABSC',
  businessarea: 'RCP1',
  profitcenter: 'RIL1',
  unit: 10,
  amountcontributed: '14790.00',
  noyearofdeductionclaimed: 3,
  allowbleyears: 5 ,
  amounteligible: 'NA',
  remarks: 'NA',
  action: 'NA',
  },
  {position: 8, servername: 'RP2', compnaycode: 'RIL2', documentnumber: 14200, trdate: '01.11.2018', glcode: 3535, glname: 'ABSC',
  businessarea: 'RCP1',
  profitcenter: 'RIL1',
  unit: 10,
  amountcontributed: '14790.00',
  noyearofdeductionclaimed: 3,
  allowbleyears: 5 ,
  amounteligible: 'NA',
  remarks: 'NA',
  action: 'NA',
  },
];

@Component({
  selector: 'app-vre',
  templateUrl: './vre.component.html',
  styleUrls: ['./vre.component.css']
})
export class VreComponent implements OnInit {

  displayedColumns: string[] = ['select', 'position', 'servername', 'compnaycode', 'documentnumber', 'trdate', 'glcode', 'glname',
  'businessarea',
  'profitcenter',
  'unit',
  'amountcontributed',
  'noyearofdeductionclaimed',
  'allowbleyears',
  'amounteligible',
  'remarks',
  'action'
  ];
  dataSource = new MatTableDataSource<VoluntaryRetirementExpenses>(ELEMENT_DATA);

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  selection = new SelectionModel<VoluntaryRetirementExpenses>(true, []);

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }

  constructor(public CAE: MatDialog) { }

  public openModal() {
    this.CAE.open(AdddeductionComponent);
  }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

}
