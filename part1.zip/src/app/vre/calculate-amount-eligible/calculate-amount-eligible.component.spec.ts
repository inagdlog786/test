import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CalculateAmountEligibleComponent } from './calculate-amount-eligible.component';

describe('CalculateAmountEligibleComponent', () => {
  let component: CalculateAmountEligibleComponent;
  let fixture: ComponentFixture<CalculateAmountEligibleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CalculateAmountEligibleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CalculateAmountEligibleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
