import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calculate-amount-eligible',
  templateUrl: './calculate-amount-eligible.component.html',
  styleUrls: ['./calculate-amount-eligible.component.css']
})
export class CalculateAmountEligibleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
