import{DepreciationServiceService} from '../depreciation-service.service';
import { Component, OnInit, ViewChild, AfterViewInit} from '@angular/core';
import {MatSort, MatPaginator, MatTableDataSource, MatDialog} from '@angular/material';

import { Observable, of,throwError, pipe } from 'rxjs';

import {DataSource} from '@angular/cdk/collections';
import { IDepreciation } from '../depreciation/IDepreciation';



@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css'],
  providers:[DepreciationServiceService]
})



export class TestComponent implements OnInit,AfterViewInit {

  displayedColumns = ['position', 'firstName', 'lastName', 'email'];
  dataSource = new MatTableDataSource();

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


//   dataSource = new TestDataSource(this._depreciationService);
//   displayedColumns = ['ID', 'Block of asset', 'Rate', 'for block of assets earlier eligible'];

//  public TestData=[] = [
//   {"No":1 ,"Block_of_Assets":"55%","Rate":"67%","asset_depn":"fDSF", "other_assets":"asdfsdf"},
//   {"No":2 ,"Block_of_Assets":"35%","Rate":"37%","asset_depn":"asdda", "other_assets":"teyahds"},
//   {"No":3 ,"Block_of_Assets":"55%","Rate":"77%","asset_depn":"poqasdjd", "other_assets":"kdjhfhs"}


// ];



                
public uploadData(event: any) : void { 
  // get data from file upload       
  let filesData = event.target.files;
  console.log(filesData[0]);
}


  constructor(private _depreciationService: DepreciationServiceService) { }
  
  ngOnInit() {
    this._depreciationService.getUsers().subscribe(
      data => {
        this.dataSource.data = data;
      }
    );

  }



  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }


}

export interface Element {
  position: number;
  firstName: string;
  lastName: string;
  email: string;
}

const ELEMENT_DATA: Element[] = [
  {position: 1, firstName: 'John', lastName: 'Doe', email: 'john@gmail.com'},
  {position: 1, firstName: 'Mike', lastName: 'Hussey', email: 'mike@gmail.com'},
  {position: 1, firstName: 'Ricky', lastName: 'Hans', email: 'ricky@gmail.com'},
  {position: 1, firstName: 'Martin', lastName: 'Kos', email: 'martin@gmail.com'},
  {position: 1, firstName: 'Tom', lastName: 'Paisa', email: 'tom@gmail.com'}
];

export class User{
  position: number
  firstName: string
  lastName: string
  email: string
}

// export class TestDataSource extends DataSource<any> {
//   constructor(private _depreciationService: DepreciationServiceService) {
//     super();
//   }
//   connect(): Observable<IDepreciation[]> {
//     console.log(this._depreciationService.getDepreciationData());
//     return this._depreciationService.getDepreciationData();
//   }
//   disconnect() {}
//}
