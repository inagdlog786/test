// export interface DialogData {
// animal: string;
// name: string;
// }
