import { Component, OnInit, ViewChild } from '@angular/core';
import { SatDatepickerRangeValue, SatDatepickerInputEvent } from 'saturn-datepicker';
import {MatSort, MatPaginator, MatTableDataSource, MatDialog} from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';
import { ModalComponent } from '../modal/modal.component';

export interface attachworkpapers {
  Description: string;
  Documentattached: string;
  NotesRemarks: string;
  Action: string;
}
const ELEMENT_DATA: attachworkpapers[] = [
  {Description: 'RCP', Documentattached: 'RP1', NotesRemarks: 'RIL1', Action: '',
  },
  {Description: 'RCP', Documentattached: 'RP1', NotesRemarks: 'RIL1', Action: '',
  },
  {Description: 'RCP', Documentattached: 'RP1', NotesRemarks: 'RIL1', Action: '',
  },
  {Description: 'RCP', Documentattached: 'RP1', NotesRemarks: 'RIL1', Action: '',
  },
  {Description: 'RCP', Documentattached: 'RP1', NotesRemarks: 'RIL1', Action: '',
},
{Description: 'ABC', Documentattached: 'RP1', NotesRemarks: 'RIL1', Action: '',
},
{Description: 'RCP', Documentattached: 'RP1', NotesRemarks: 'RIL1', Action: '',
},
{Description: 'XYZ', Documentattached: 'RP1', NotesRemarks: 'RIL1', Action: '',
},
{Description: 'RCP', Documentattached: 'RP1', NotesRemarks: 'RIL1', Action: '',
},
{Description: 'RCP', Documentattached: 'RP1', NotesRemarks: 'RIL1', Action: '',
},
{Description: 'RCP', Documentattached: 'RP1', NotesRemarks: 'RIL1', Action: '',
},
{Description: 'RCP', Documentattached: 'RP1', NotesRemarks: 'RIL1', Action: '',
},
];

@Component({
  selector: 'app-attachwp',
  templateUrl: './attachwp.component.html',
  styleUrls: ['./attachwp.component.css']
})
export class AttachwpComponent implements OnInit {
displayedColumns: string[] = ['Description', 'Documentattached', 'NotesRemarks', 'Action'];
columnsToDisplay: string[] = this.displayedColumns.slice();
data: attachworkpapers[] = ELEMENT_DATA;
dataSource = new MatTableDataSource<attachworkpapers>(ELEMENT_DATA);

@ViewChild(MatPaginator) paginator: MatPaginator;
@ViewChild(MatSort) sort: MatSort;



selection = new SelectionModel<attachworkpapers>(true, []);
// Date Range
date: SatDatepickerRangeValue<Date> ;
lastDateInput: SatDatepickerRangeValue<Date>  | null;
lastDateChange: SatDatepickerRangeValue<Date>  | null;

onDateInput = (e: SatDatepickerInputEvent<Date>) => this.lastDateInput = e.value as SatDatepickerRangeValue<Date>;
onDateChange = (e: SatDatepickerInputEvent<Date>) => this.lastDateChange = e.value as SatDatepickerRangeValue<Date>;

public show:boolean = false;
public buttonName:any = 'Show';

  
  constructor(public CAE: MatDialog ) { }
  public openModal() {
 
     this.CAE.open(ModalComponent)
     };
  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
    // toggle() {
    //   this.show = !this.show;
    //   if(this.show)  
    //     this.buttonName = "Hide";
    //   else
    //     this.buttonName = "Show";
    // }
    togglebck(){
      this.show = !this.show;
      if(this.show)  
        this.buttonName = "Hide";
      else
        this.buttonName = "Show";
    }
    addColumn(){
        const randomColumn = Math.floor(Math.random() * this.displayedColumns.length);
        this.columnsToDisplay.push(this.displayedColumns[randomColumn]);        
      }
  }

