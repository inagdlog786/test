import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AttachwpComponent } from './attachwp.component';

describe('AttachwpComponent', () => {
  let component: AttachwpComponent;
  let fixture: ComponentFixture<AttachwpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AttachwpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AttachwpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
