import { Injectable } from '@angular/core';
import { HttpClient,HttpClientModule } from '@angular/common/http';
import { Http,Response } from "@angular/http";
import { IDepreciation } from '../app/depreciation/IDepreciation';
import { Observable, of,throwError, pipe } from 'rxjs';
import { map, filter, catchError,mergeMap } from 'rxjs/operators';
import { HttpHeaders, HttpResponse } from '@angular/common/http';
import {User} from '../app/test/test.component';



@Injectable({
  providedIn: 'root'
})
export class DepreciationServiceService {

  private _url:string ="/assets/data/depreciation.json";
  //private _url:string ="http://localhost:3000/depreciation_view_all";
 private saveURL:string="http://localhost:4000/depreciation_save";
  
  private _Usersurl:string ="/assets/data/Users.json";

  constructor(private http: HttpClient) { }

  //getDepreciationData():Observable<IDepreciation[]> {
  //  return this.http.get<IDepreciation[]>(this._url);
  //}

  getDepreciationData(): Observable<any> {
    //debugger;
    return this.http.get(this._url)
    .pipe(map(result => result));
}

saveDataToDb(any: data): Observable<HttpResponse<any>> {
  var json = {};
    json.test_array = any;

    console.log(json);

	let httpHeaders = new HttpHeaders({
		 'Content-Type' : 'application/json'
	});    
	return this.http.post<any>(this.saveURL, json,
		{
		  headers: httpHeaders,
		  observe: 'response'
		}
	);
} 
  // getDepData() {
  //   return this.http.get('/assets/data/depreciation.json').pipe(map((response: any) => response.json()));

  // }
  /*saveDataToDb(data:data){
    var json = {};
    json.test_array = data;

    console.log(json);
    return this.http.post(this.saveURL, json);
  }*/
  
  

  // public getUsers(): Observable<any> {
  //   let fakeUsers : User[] = [{position: 1, firstName: 'Dhiraj', lastName: 'Ray', email: 'dhiraj@gmail.com'},
  //     {position: 2, firstName: 'Tom', lastName: 'Jac', email: 'Tom@gmail.com'},
  //     {position: 3, firstName: 'Hary', lastName: 'Pan', email: 'hary@gmail.com'},
  //     {position: 4, firstName: 'praks', lastName: 'pb', email: 'praks@gmail.com'},
  //   ];
  //   return Observable.of(fakeUsers).delay(500);

  // }
    
  public getUsers(): Observable<any> {
    return this.http.get(this._Usersurl)
    .pipe(map(result => result));
}

  

}
