import { Component, OnInit , ViewChild } from '@angular/core';
import {SelectionModel} from '@angular/cdk/collections';
import {MatSort, MatPaginator, MatTableDataSource, MatDialog} from '@angular/material';

import { NgModule } from '@angular/core';
import { DpothersComponent } from '../depreciation/dpothers/dpothers.component';

export interface tbldepriciation {
  servername: string;
  position: number;
  compnaycode: string;
  documentnumber: number;
  trdate: String;
  action: string;
}
const ELEMENT_DATA: tbldepriciation[] = [
  {position: 1, servername: 'RP1', compnaycode: 'RIL1', documentnumber: 14235, trdate: '01.11.2018', action: 'NA',
  },
  {position: 2, servername: 'RP2', compnaycode: 'RIL2', documentnumber: 14200, trdate: '01.11.2018', action: 'NA',
  },
  {position: 3, servername: 'RP3', compnaycode: 'RIL3', documentnumber: 14200, trdate: '01.11.2018', action: 'NA',
  },
  {position: 4, servername: 'RP2', compnaycode: 'RIL2', documentnumber: 14200, trdate: '01.11.2018', action: 'NA',
  },
  {position: 5, servername: 'RP2', compnaycode: 'RIL2', documentnumber: 14200, trdate: '01.11.2018', action: 'NA',
  },
  {position: 6, servername: 'RP2', compnaycode: 'RIL2', documentnumber: 14200, trdate: '01.11.2018', action: 'NA',
  },
  {position: 7, servername: 'RP2', compnaycode: 'RIL2', documentnumber: 14200, trdate: '01.11.2018', action: 'NA',
  },
  {position: 8, servername: 'RP2', compnaycode: 'RIL2', documentnumber: 14200, trdate: '01.11.2018', action: 'NA',
  },
];



@Component({
  selector: 'app-uploadpage',
  templateUrl: './uploadpage.component.html',
  styleUrls: ['./uploadpage.component.css']
})
export class UploadpageComponent implements OnInit {displayedColumns: string[] = ['select', 'position', 'servername', 'compnaycode',
'documentnumber', 'trdate',
'action'
];
  dataSource = new MatTableDataSource<tbldepriciation>(ELEMENT_DATA);
  
  
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  
  
  selection = new SelectionModel<tbldepriciation>(true, []);
  
  
  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }
  
  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }
  
  constructor(public CAE: MatDialog) { }

  public openModal() {
    this.CAE.open(DpothersComponent);
  }
  
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  
  ngOnInit() {
    this.dataSource.paginator = this.paginator;
  this.dataSource.sort = this.sort;
  }

}
